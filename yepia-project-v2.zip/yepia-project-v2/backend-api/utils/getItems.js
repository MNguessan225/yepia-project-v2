
const { buildErrObject } = require('./buildErrObject')
const { cleanPaginationID } = require('./cleanPaginationID')
const { listInitOptions } = require('./listInitOptions')

/**
 * Gets items from database
 * @param {Object} req - request object
 * @param {Object} query - query object
 */
const getItems = async (model, filter = {}, options = {}) => {
  const page = parseInt(options.page) || 1; // Default to page 1
  const limit = parseInt(options.limit) || 10; // Default to limit 10
  const sort = options.sort || {}; // Default sorting (if needed)
  try {
    // 1. Fetch the data
    const data = await model
      .find(filter)       // Apply the filter
      .skip((page - 1) * limit) // Skip the records based on the page
      .limit(limit)       // Limit the results to the current page size
      .sort(sort)         // Optional sorting
      .exec();

    // 2. Get the total document count
    const totalDocs = await model.countDocuments(filter);

    // 3. Calculate total pages
    const totalPages = Math.ceil(totalDocs / limit);

    // 4. Return the paginated data and metadata
    return {
      results: data,         // The paginated documents
      totalDocs,          // Total number of documents
      limit,              // Limit per page
      page,               // Current page
      totalPages,         // Total number of pages
      hasNextPage: page < totalPages,  // Check if next page exists
      hasPrevPage: page > 1,           // Check if previous page exists
      nextPage: page < totalPages ? page + 1 : null, // Next page number
      prevPage: page > 1 ? page - 1 : null           // Previous page number
    };
  } catch (error) {
    throw new Error(error.message);
  }
}

module.exports = {getItems}
