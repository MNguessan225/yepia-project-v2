// Check product promotion validity

const promotionAvailable = async  (product) => {
    if (product.promotion && product.promotion.active) {
        const current_date = new Date().getTime();
        const start_date = new Date(product.promotion.start_dt).getTime();
        const end_date = new Date(product.promotion.end_dt).getTime();

        const percent = 100 - ((product.promotion.cost * 100) / product.price)

        if((start_date <= current_date) && (current_date <= end_date) ) {
            
            return {
                _id : product._id,
                title : product.title,
                slug : product.slug,
                description : product.description,
                specifications : product.specifications,
                category_level_one : product.category_level_one,
                category_level_two : product.category_level_two,
                category_level_three : product.category_level_three,
                brand : product.brand,
                model : product.model,
                price : product.price,
                promotion : {
                    active: true,
                    percent: Math.round(percent),
                    start_date: product.promotion.start_dt,
                    end_dt: product.promotion.end_dt,
                    cost: product.promotion.cost
                },
                images : product.images,
                reviews : product.reviews,
                active : product.active,
                status : product.status,
                ratings : product.ratings,
                sold_out : product.sold_out,
                viewed_nb : product.viewed_nb,
                stock : product.stock,
                created_at : product.created_at,
                updated_at : product.updated_at,
                created_by : product.created_by,
                updated_by : product.updated_by
            }
        }else {
            return {
                _id : product._id,
                title : product.title,
                slug : product.slug,
                description : product.description,
                specifications : product.specifications,
                category_level_one : product.category_level_one,
                category_level_two : product.category_level_two,
                category_level_three : product.category_level_three,
                brand : product.brand,
                model : product.model,
                price : product.price,
                promotion : {
                    active: false,
                    percent: Math.round(percent),
                    start_date: product.promotion.start_dt,
                    end_dt: product.promotion.end_dt,
                    cost: product.promotion.cost
                },
                images : product.images,
                reviews : product.reviews,
                active : product.active,
                status : product.status,
                ratings : product.ratings,
                sold_out : product.sold_out,
                viewed_nb : product.viewed_nb,
                stock : product.stock,
                created_at : product.created_at,
                updated_at : product.updated_at,
                created_by : product.created_by,
                updated_by : product.updated_by
            }
        }
      
    }else {
        return {
            _id : product._id,
            title : product.title,
            slug : product.slug,
            description : product.description,
            specifications : product.specifications,
            category_level_one : product.category_level_one,
            category_level_two : product.category_level_two,
            category_level_three : product.category_level_three,
            brand : product.brand,
            model : product.model,
            price : product.price,
            promotion : {
                active: false,
                percent: 0,
                start_date: product.promotion.start_dt,
                end_dt: product.promotion.end_dt,
                cost: product.promotion.cost
            },
            images : product.images,
            reviews : product.reviews,
            active : product.active,
            status : product.status,
            ratings : product.ratings,
            sold_out : product.sold_out,
            viewed_nb : product.viewed_nb,
            stock : product.stock,
            created_at : product.created_at,
            updated_at : product.updated_at,
            created_by : product.created_by,
            updated_by : product.updated_by
        }
    }
}

module.exports = promotionAvailable;