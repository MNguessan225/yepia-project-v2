// create token and saving that in cookies
const sendToken = (user, statusCode, res) => {
  const token = user.getJwtToken();
  const refres_token = user.getJwtRefreshToken();

  // Options for cookies
  const options = {
    expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    httpOnly: true,
    sameSite: "none",
    secure: true,
  };

  res.status(statusCode)
  .cookie("acces_token", token, options)
  .cookie("refresh_token", refres_token, options)
  .json({
    success: true,
    user: {
      _id: user._id,
      first_name: user.first_name,
      last_name: user.last_name,
      full_name: user.full_name,
      email_address: user.email_address,
      password: user.password,
      location: user.location,
      phone_numbers: user.phone_numbers,
      role: user.role,
      gender: user.gender,
      action: user.action,
      avatar: user.avatar,
      is_activated: user.is_activated,
      created_at: user.created_at,
      updated_at: user.updated_at,
      created_by: user.created_by,
      updated_by: user.updated_by,
      wish_list_ids: user.wish_list_ids,
      viewed_list_ids: user.viewed_list_ids,
      viewed_products: user.viewed_products, 
      wish_products: user.wish_products
    },
    acces_token: token,
    refresh_token: refres_token
  });
};

module.exports = sendToken;
