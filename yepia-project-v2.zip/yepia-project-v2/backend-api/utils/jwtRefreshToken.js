const ErrorHandler = require("./ErrorHandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const jwt = require("jsonwebtoken");

// create token and saving that in cookies
const sendNewToken = (refreshToken, statusCode, res) => {
  jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET_KEY, (err, user) => {

    if (err) return next(new ErrorHandler("Token expired, please log again", 403));

    const accessToken = jwt.sign({ id: user._id}, process.env.JWT_SECRET_KEY,{
      expiresIn: process.env.JWT_EXPIRES,
    });
    res.status(statusCode)
    .cookie("acces_token", accessToken, options)
    .json({
      success: true,
      acces_token: accessToken
    });
});

  
};

module.exports = sendNewToken;
