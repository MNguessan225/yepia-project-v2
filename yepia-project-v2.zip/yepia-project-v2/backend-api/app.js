const express = require("express");
const ErrorHandler = require("./middleware/error");
const app = express();
const cookieParser = require("cookie-parser");
const bodyParser = require("body-parser");
const cors = require("cors");

app.use(cors({
  origin: [`http://localhost:3000`,`http://localhost:3001`],
  credentials: true
}));

app.use(express.json());
app.use(cookieParser());
app.use("/test", (req, res) => {
  res.send("Hello world!");
});

// Increase the limit to, for example, 50mb
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

// config
if (process.env.NODE_ENV !== "PRODUCTION") {
  require("dotenv").config({
    path: "config/.env",
  });
}

// import routes
const banner = require("./controller/banner");
const blog = require("./controller/blog");
const brand = require("./controller/brand");
const category = require("./controller/category");
const conversation = require("./controller/conversation");
const coupon = require("./controller/coupounCode");
const message = require("./controller/message");
const newsletter = require("./controller/newsletter");
const order = require("./controller/order");
const product = require("./controller/product");
const room = require("./controller/room");
const sva = require("./controller/sva");
const user = require("./controller/user");
const withdraw = require("./controller/withdraw");
const image = require("./controller/image");

app.use("/api/v1/banner", banner);
app.use("/api/v1/image", image);
app.use("/api/v1/blog", blog);
app.use("/api/v1/brand", brand);
app.use("/api/v1/category", category);
app.use("/api/v1/conversation", conversation);
app.use("/api/v1/coupon", coupon);
app.use("/api/v1/message", message);
app.use("/api/v1/newsletter", newsletter);
app.use("/api/v1/order", order);
app.use("/api/v1/product", product);
app.use("/api/v1/room", room);
app.use("/api/v1/sva", sva);
app.use("/api/v1/user", user);
app.use("/api/v1/withdraw", withdraw);

// it's for ErrorHandling
app.use(ErrorHandler);

module.exports = app;
