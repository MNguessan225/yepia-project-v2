const express = require("express");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/ErrorHandler");
const { isAdmin, isAdminCanDo, isAuthenticated } = require("../middleware/auth");
const Banner = require("../model/banner");
const { getItems } = require("../utils/getItems");
const router = express.Router();
const cloudinary = require("cloudinary");

// create banner
router.post(
  "/",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const isBannerExists = await Banner.findOne({
        position: req.body.position,
      });

      if (isBannerExists) {
        return next(new ErrorHandler("Banner already exists at this position!", 400));
      }

      const banner = await Banner.create(req.body);

      res.status(201).json(banner);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// update banner
router.put(
  "/update/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { link, position, image } = req.body;

      const banner = await Banner.findById(req.params.id);

      if (!banner) {
        return next(new ErrorHandler("Banner not found with this id", 400));
      }

      const isBannerExists = await Banner.findOne({
        position: position,
      });

      if (isBannerExists  && banner.position !== position) {
        return next(new ErrorHandler("Another banner already exists at this position!", 400));
      }

      banner.link = link;
      banner.image = image;
      banner.position = position;
      banner.updated_at = req.user._id;

      await banner.save({ validateBeforeSave: false });
      res.status(201).json(banner);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// delete banner
router.delete(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const banner = await Banner.findByIdAndDelete(req.params.id);

      if (!banner) {
        return next(new ErrorHandler("Banner dosen't exists!", 400));
      }

      if (banner.image) {
        const result = await cloudinary.v2.uploader.destroy(
          banner.image.public_id
        );
      }

      res.status(201).json({
        success: true,
        message: "Banner deleted successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get all banners
router.get(
  "/",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const filter = {};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          _id: 1
        }
      };
      res.status(201).json(await getItems(Banner, filter, options));
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);


// load banner with id
router.get(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const banner = await Banner.findById(req.params.id);

      if (!banner) {
        return next(new ErrorHandler("Banner doesn't exists", 400));
      }

      res.status(200).json(banner);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);
module.exports = router;
