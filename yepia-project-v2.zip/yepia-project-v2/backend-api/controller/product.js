const express = require("express");
const { isAdminCanDo, isAuthenticated, isAdmin } = require("../middleware/auth");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const router = express.Router();
const Product = require("../model/product");
const Order = require("../model/order");
const User = require("../model/user");
const cloudinary = require("cloudinary");
const ErrorHandler = require("../utils/ErrorHandler");
const promotionAvailable = require("../utils/promotionValidity");
const slugify = require("slugify");
const { getItems } = require("../utils/getItems");
const multer = require('multer');
const fs = require('fs');
const upload = multer({ dest: 'uploads/', limits: { fileSize: 1 * 1024 * 1024 } });
// create product
router.post(
  "/",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
        
        req.body.created_by = req.user._id;
        const productData = req.body;
        productData.slug = slugify(req.body.title);

        const product = await Product.create(productData);

        res.status(201).json({
          success: true,
          product,
        });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// update product
router.put(
"/update/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const {
      title,
      description,
      specifications,
      category_level_one_id,
      category_level_two_id,
      category_level_three_id,
      brand_id,
      model_id,
      price,
      promotion,
      stock,
      images,
      active,
      status
    }  = req.body;

      const product = await Product.findById(req.params.id);

      if (!product) {
        return next(new ErrorHandler("Brand not found with this id", 400));
      }

      

      product.title = title;
      product.description = description;
      product.specifications = specifications;
      product.category_level_one_id = category_level_one_id;
      product.category_level_two_id = category_level_two_id;
      product.category_level_three_id = category_level_three_id;
      product.brand_id = brand_id;
      product.model_id = model_id;
      product.price = price;
      product.promotion = promotion;
      product.stock = stock;
      product.active = active;
      product.status = status;
      product.images = images;
      product.slug = slugify(title);
      product.updated_by = req.user._id;

      await product.save({ validateBeforeSave: false });
      res.status(201).json({
        success: true,
        product,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// delete product
router.delete(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const product = await Product.findById(req.params.id);

      if (!product) {
        return next(new ErrorHandler("Product is not found with this id", 404));
      }    

      for (let i = 0; 1 < product.images.length; i++) {

        if(product.images[i]) {
          const result = await cloudinary.v2.uploader.destroy(
            product.images[i].public_id
          );
        }
      }
    
      await product.deleteOne();

      res.status(201).json({
        success: true,
        message: "Product Deleted successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);


// get all products admins
router.get(
  "/admin",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          active: 1,
          created_at: -1,
          _id: 1
        }
      };

      if (req.query.search) {
        filter = {
          $or: [
            {
              title: {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              description: {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              specifications: {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              'category_level_one.name': {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              'category_level_two.name': {
                $regex: new RegExp(req.query.search, 'i')
              }
            }
          ]
        }
      }

      const itemsPaginated = await getItems(Product, filter, options)
      
      let results = []

      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          results.push(await promotionAvailable(product))
        })
      )
      
      res.status(201).json({...itemsPaginated,
        results
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// search product
router.get(
  "/search",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {active: true};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          _id: 1
        }
      };

      if (req.query.search) {
        filter = {
          $or: [
            {
              title: {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              description: {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              specifications: {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              'category_level_one.name': {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              'category_level_two.name': {
                $regex: new RegExp(req.query.search, 'i')
              }
            }
          ]
        }
      }

      const itemsPaginated = await getItems(Product, filter, options)
      
      let results = []

      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          results.push(await promotionAvailable(product))
        })
      )
      
      res.status(201).json({...itemsPaginated,
        results
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);


// get all promoted and most cheaper products
router.get(
  "/most-promoted-and-cheaper",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {active: true};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          _id: 1
        }
      };

      const itemsPaginated = await getItems(Product, filter, options)
      let updatedProducts = []
      
      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          updatedProducts.push(await promotionAvailable(product))
        })
      )

      const promotedData = updatedProducts.filter(product => product.promotion && product.promotion.active === true );
      
      let results = []
      if(promotedData.length) {
        promotedData.sort((a, b) => b.promotion.percent - a.promotion.percent);
        results = promotedData;
      }else {
        updatedProducts.sort((a, b) => a.price - b.price);
        results = updatedProducts;
      }

      res.status(201).json({...itemsPaginated,
        results
      });
      
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get most popular products
router.get(
  "/most-popular",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {active: true};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          _id: 1
        }
      };

      const itemsPaginated = await getItems(Product, filter, options)
      let updatedProducts = []
      
      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          updatedProducts.push(await promotionAvailable(product))
        })
      )
      updatedProducts.sort((a, b) => b.viewed_nb - a.viewed_nb);


      res.status(201).json({...itemsPaginated,
        results: updatedProducts
      });

    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get new arrivals products
router.get(
  "/new-arrivals",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {active: true};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          created_at: -1,
          title: 1,
          status: -1,
          sold_out: -1,
          _id: 1
        }
      };

      const itemsPaginated = await getItems(Product, filter, options)
      let results = []
      
      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          results.push(await promotionAvailable(product))
        })
      )
      

      res.status(201).json({...itemsPaginated,
        results
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get big stockage products
router.get(
  "/big-stockage",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {active: true};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          stock: -1,
          status: -1,
          sold_out: -1,
          _id: 1
        }
      };

      const itemsPaginated = await getItems(Product, filter, options)
      let results = []
      
      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          results.push(await promotionAvailable(product))
        })
      )
      

      res.status(201).json({...itemsPaginated,
        results
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get best seller products
router.get(
  "/best-seller",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {active: true};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          sold_out: -1,
          viewed_nb: -1,
          _id: 1
        }
      };

      const itemsPaginated = await getItems(Product, filter, options)
      let results = []
      
      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          results.push(await promotionAvailable(product))
        })
      )
      
      res.status(201).json({...itemsPaginated,
        results
      });

      
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get full users products
router.get(
  "/full",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {active: true};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          viewed_nb: -1,
          sold_out: -1,
          created_at: -1,
          _id: 1
          
        }
      };

      const itemsPaginated = await getItems(Product, filter, options)
      let results = []
      
      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          results.push(await promotionAvailable(product))
        })
      )
      

      res.status(201).json({...itemsPaginated,
        results
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get products by category
router.get(
  "/category/:slug",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {"category_level_one.slug": req.params.slug};  // Apply your custom filter here
      let options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          _id: 1
        }
      };

      if(req.query.filter &&  req.query.filter === 'most-popular') {
        options = {
          ...options,
          sort: {
            viewed_nb: -1,
            ...options.sort
          }
        }
      }
      if(req.query.filter &&  req.query.filter === 'new-arrival' ) {
        options = {
          ...options,
          sort: {
            created_at: -1,
            ...options.sort
          }
        }
      }
      if(req.query.filter &&  req.query.filter === 'price-az' ) {
        options = {
          ...options,
          sort: {
            price: 1,
            ...options.sort
          }
        }
      }

      if(req.query.filter &&  req.query.filter === 'price-za') {
        options = {
          ...options,
          sort: {
            price: -1,
            ...options.sort
          }
        }
      }
      

      const itemsPaginated = await getItems(Product, filter, options)
      let results = []
      
      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          results.push(await promotionAvailable(product))
        })
      )
      

      res.status(201).json({...itemsPaginated,
        results
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get products by category level two
router.get(
  "/category-level-two/:slug",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {"category_level_two.slug": req.params.slug};  // Apply your custom filter here
      let options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          _id: 1
        }
      };

      if(req.query.filter &&  req.query.filter === 'most-popular') {
        options = {
          ...options,
          sort: {
            viewed_nb: -1,
            ...options.sort
          }
        }
      }
      if(req.query.filter &&  req.query.filter === 'new-arrival' ) {
        options = {
          ...options,
          sort: {
            created_at: -1,
            ...options.sort
          }
        }
      }
      if(req.query.filter &&  req.query.filter === 'price-az' ) {
        options = {
          ...options,
          sort: {
            price: 1,
            ...options.sort
          }
        }
      }

      if(req.query.filter &&  req.query.filter === 'price-za') {
        options = {
          ...options,
          sort: {
            price: -1,
            ...options.sort
          }
        }
      }

      const itemsPaginated = await getItems(Product, filter, options)
      let results = []
      
      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          results.push(await promotionAvailable(product))
        })
      )
      

      res.status(201).json({...itemsPaginated,
        results
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get products by category level three
router.get(
  "/category-level-three/:slug",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {"category_level_three.slug": req.params.slug};  // Apply your custom filter here
      let options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          _id: 1
        }
      };

      if(req.query.filter &&  req.query.filter === 'most-popular') {
        options = {
          ...options,
          sort: {
            viewed_nb: -1,
            ...options.sort
          }
        }
      }
      if(req.query.filter &&  req.query.filter === 'new-arrival' ) {
        options = {
          ...options,
          sort: {
            created_at: -1,
            ...options.sort
          }
        }
      }
      if(req.query.filter &&  req.query.filter === 'price-az' ) {
        options = {
          ...options,
          sort: {
            price: 1,
            ...options.sort
          }
        }
      }

      if(req.query.filter &&  req.query.filter === 'price-za') {
        options = {
          ...options,
          sort: {
            price: -1,
            ...options.sort
          }
        }
      }

      const itemsPaginated = await getItems(Product, filter, options)
      let results = []
      
      await Promise.all(
        itemsPaginated.results.map(async (product) => {
          results.push(await promotionAvailable(product))
        })
      )
      

      res.status(201).json({...itemsPaginated,
        results
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);


// get product by id
router.get(
  "/detailed/:id",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const product = await Product.findById(req.params.id);

      if (!product) {
        return next(new ErrorHandler("Product doesn't exists", 400));
      }

      res.status(200).json(product);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// get product by slug
router.get(
  "/detailed/:slug",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const product = await Product.findOne({slug: req.params.slug});

      if (!product) {
        return next(new ErrorHandler("Product doesn't exists", 400));
      }

      if (!product.active) {
        return next(new ErrorHandler("Product doesn't exists", 400));
      }

      res.status(200).json(product);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// view a product
router.put(
  "/view/:id",
  catchAsyncErrors(async (req, res, next) => {
    try {

      let userReturnData = null
      if(req.user) {
        const user = await User.findById(req.user._id)
        const alreadyadded = user.viewed_list_ids.find((id) => id.toString() === req.params.id);
        if (!alreadyadded) {
          const userData = await User.findByIdAndUpdate(
            req.user._id,
            {
              $push: { viewed_list_ids: req.params.id },
            },
            {
              new: true,
            }
          )
          .select('+password');

          let viewedProducts = [];

          await Promise.all(
            userData.viewed_list_ids.map(async (id) => {
              const product = await Product.findById(id);
              viewedProducts.push(product)
            })
          )

          const _userData = {
            _id: user._id,
            first_name: userData.first_name,
            last_name: userData.last_name,
            full_name: userData.full_name,
            email_address: userData.email_address,
            password: userData.password,
            location: userData.location,
            phone_numbers: userData.phone_numbers,
            role: userData.role,
            gender: userData.gender,
            action: userData.action,
            avatar: userData.avatar,
            is_activated: userData.is_activated,
            created_at: userData.created_at,
            updated_at: userData.updated_at,
            created_by: userData.created_by,
            updated_by: userData.updated_by,
            wish_list_ids: userData.wish_list_ids,
            viewed_list_ids: userData.viewed_list_ids,
            viewed_products: viewedProducts
          }

          userReturnData =_userData
        } 
      }
      await Product.findByIdAndUpdate(
        req.params.id,
        {
          $inc: { viewed_nb: 1 },
        },
        {
          new: true,
        }
      )
      if(req.user) {
        res.status(200).json({
          success: true,
          message: "Ok!",
          user: userReturnData
        });
      }else {
        res.status(200).json({
          success: true,
          message: "Ok!",
        });
      }
      
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// add product to wish list
router.put(
  "/wish/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {

      const user = await User.findById(req.user._id)
      const alreadyadded = user.wish_list_ids.find((id) => id.toString() === req.params.id);
      if (alreadyadded) {
        const userData = await User.findByIdAndUpdate(
        req.user._id,
        {
          $pull: { wish_list_ids: req.params.id },
        },
        {
          new: true,
        }
        )
        .select('+password');

        let wishProducts = [];

        await Promise.all(
          userData.wish_list_ids.map(async (id) => {
            const product = await Product.findById(id);
            wishProducts.push(product)
          })
        )

        const _userData = {
          _id: user._id,
          first_name: userData.first_name,
          last_name: userData.last_name,
          full_name: userData.full_name,
          email_address: userData.email_address,
          password: userData.password,
          location: userData.location,
          phone_numbers: userData.phone_numbers,
          role: userData.role,
          gender: userData.gender,
          action: userData.action,
          avatar: userData.avatar,
          is_activated: userData.is_activated,
          created_at: userData.created_at,
          updated_at: userData.updated_at,
          created_by: userData.created_by,
          updated_by: userData.updated_by,
          wish_list_ids: userData.wish_list_ids,
          viewed_list_ids: userData.viewed_list_ids,
          wish_products: wishProducts
        }
        
        res.status(200).json({
          success: true,
          message: "Product removed from wish list!",
          user: _userData
        });
      }else {
        const userData = await User.findByIdAndUpdate(
          req.user._id,
          {
            $push: { wish_list_ids: req.params.id },
          },
          {
            new: true,
          }
        )
        .select('+password');

        let wishProducts = [];

        await Promise.all(
          userData.wish_list_ids.map(async (id) => {
            const product = await Product.findById(id);
            wishProducts.push(product)
          })
        )

        const _userData = {
          _id: user._id,
          first_name: userData.first_name,
          last_name: userData.last_name,
          full_name: userData.full_name,
          email_address: userData.email_address,
          password: userData.password,
          location: userData.location,
          phone_numbers: userData.phone_numbers,
          role: userData.role,
          gender: userData.gender,
          action: userData.action,
          avatar: userData.avatar,
          is_activated: userData.is_activated,
          created_at: userData.created_at,
          updated_at: userData.updated_at,
          created_by: userData.created_by,
          updated_by: userData.updated_by,
          wish_list_ids: userData.wish_list_ids,
          viewed_list_ids: userData.viewed_list_ids,
          wish_products: wishProducts
        }
        
        res.status(200).json({
          success: true,
          message: "Product added to wish list!",
          user: _userData
        });
      }
      
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// review a product
router.put(
  "/review/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { user, rating, comment, orderId } = req.body;

      const product = await Product.findById(req.params.id);

      const review = {
        user,
        rating,
        comment,
        product_id: req.params.id,
        created_at: Date.now()
      };

      const isReviewed = product.reviews.find(
        (rev) => rev.user._id === req.user._id
      );

      if (isReviewed) {
        product.reviews.forEach((rev) => {
          if (rev.user._id === req.user._id) {
            (rev.rating = rating), (rev.comment = comment), (rev.user = user);
          }
        });
      } else {
        product.reviews.push(review);
      }

      let avg = 0;

      product.reviews.forEach((rev) => {
        avg += rev.rating;
      });

      product.ratings = avg / product.reviews.length;

      await product.save({ validateBeforeSave: false });

      await Order.findByIdAndUpdate(
        orderId,
        { $set: { "cart.$[elem].isReviewed": true } },
        { arrayFilters: [{ "elem._id": req.params.id }], new: true }
      );

      res.status(200).json({
        success: true,
        message: "Reviwed succesfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

module.exports = router;

