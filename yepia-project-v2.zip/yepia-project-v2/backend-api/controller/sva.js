const express = require("express");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/ErrorHandler");
const { isAdmin, isAdminCanDo, isAuthenticated } = require("../middleware/auth");
const Sva = require("../model/sva");
const { sendMail, receiveMail } = require("../utils/sendMail");
const { getItems } = require("../utils/getItems");
const router = express.Router();

// create sva
router.post(
  "/",
  catchAsyncErrors(async (req, res, next) => {
    try {
      
      const sva = await Sva.create(req.body);

      
      try {
        await sendMail({
          email_address: req.body.email_address,
          subject: `Demande de Service Après Vente pour l'appareil ${req.body.device_name}${req.body.order_id ? ` contenu dans la commande N°${req.body.order_id}`:''}`,
          message: `Bonjour ${req.body.full_name} <br/> votre demande à notre Service Après Vente pour l'appareil N°${req.body.device_name}${req.body.order_id ? ` contenu dans la commande N°${req.body.order_id}`:''}, a été réçue avec ssuccès.`,
        });
        await receiveMail({
          email_address: req.body.email_address,
          subject: `Demande de Service Après Vente pour l'appareil ${req.body.device_name}${req.body.order_id ? ` contenu dans la commande N°${req.body.order_id}`:''}`,
          message: `Bonjour, <br/> ${req.body.full_name} vient de faire une demande de notre Service Après Vente pour l'appareil N°${req.body.device_name}${req.body.order_id ? ` contenu dans la commande N°${req.body.order_id}`:''}.`,
        });
        res.status(201).json({
          success: true,
          sva,
        });
      } catch (error) {
        return next(new ErrorHandler(error.message, 500));
      }
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// update sva
router.put(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "sva-manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { is_new, status } = req.body;
      const sva = await Sva.findById(req.params.id);

      if (!sva) {
        return next(new ErrorHandler("Sva not found with this id", 400));
      }

      sva.is_new = is_new;
      sva.status = status;
      sva.updated_by = req.user._id;
      sva.traited_by = req.user;
      await sva.save({ validateBeforeSave: false });
      res.status(201).json({
        success: true,
        sva,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get all svas
router.get(
  "/",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker", "sva-manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          is_new: -1,
          created_at: -1,
          _id: 1
        }
      };

      res.status(201).json(await getItems(Sva, filter, options));
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// load sva with id
router.get(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const sva = await Sva.findById(req.params.id);

      if (!sva) {
        return next(new ErrorHandler("Sva doesn't exists", 400));
      }

      res.status(200).json(sva);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
