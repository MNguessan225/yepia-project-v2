const ErrorHandler = require("../utils/ErrorHandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const express = require("express");
const { isAuthenticated, isAdmin, isAdminCanDo } = require("../middleware/auth");
const Withdraw = require("../model/withdraw");
const router = express.Router();

// get all withdraws --- admnin

router.get(
  "/",
  isAuthenticated,
  isAdmin("Admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const withdraws = await Withdraw.find().sort({ createdAt: -1 });

      res.status(201).json({
        success: true,
        withdraws,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
