const express = require("express");
const User = require("../model/user");
const Product = require("../model/product");
const router = express.Router();
const cloudinary = require("cloudinary");
const ErrorHandler = require("../utils/ErrorHandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const jwt = require("jsonwebtoken");
const {sendMail} = require("../utils/sendMail");
const sendToken = require("../utils/jwtToken");
const sendNewToken = require("../utils/jwtRefreshToken");
const { isAuthenticated, isAdmin, isAdminCanDo } = require("../middleware/auth");
const { getItems } = require("../utils/getItems");
const Newsletter = require("../model/newsletter");

router.post("/", async (req, res, next) => {
  try {
    const { first_name, last_name, email_address, password, location, phone_numbers, role, gender, action } = req.body;
    const userEmail = await User.findOne({ email_address });

    if (userEmail) {
      return next(new ErrorHandler("User already exists", 400));
    }

    let avatarData = null;
    if(req.body.avatar) {
      avatarData = eq.body.avatar
    }

    const fullName = `${first_name} ${last_name}`

    const user = {
      first_name: first_name,
      last_name: last_name,
      full_name: fullName,
      email_address: email_address,
      password: password,
      location: location,
      phone_numbers: phone_numbers,
      role: role,
      gender: gender,
      action: action,
      avatar: avatarData
    };

    const activationToken = createActivationToken(user);

    const activationUrl = `${process.env.PORTAL_PORT}/activation/${activationToken}`;

    try {
      await sendMail({
        email_address: user.email_address,
        subject: "Activation de votre compte",
        message: `Bonjour ${user.full_name}, veuillez <a href='${activationUrl}' >cliquer ici </a> ou sur le lien suivant pour activer votre compte: <a href='${activationUrl}' >${activationUrl}</a>`,
      });
      res.status(201).json({
        success: true,
        message: `please check your email:- ${user.email_address} to activate your account! ${activationToken}`,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  } catch (error) {
    return next(new ErrorHandler(error.message, 400));
  }
});

// create activation token
const createActivationToken = (user) => {
  return jwt.sign(user, process.env.ACTIVATION_SECRET, {
    expiresIn: "5m",
  });
};

// activate user
router.post(
  "/activation",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { activation_token } = req.body;

      const newUser = jwt.verify(
        activation_token,
        process.env.ACTIVATION_SECRET
      );

      if (!newUser) {
        return next(new ErrorHandler("Invalid token", 400));
      }
      const { first_name, last_name, full_name, email_address, password, location, phone_numbers, role, gender, action, avatar } = newUser;

      let user = await User.findOne({ email_address });

      if (user) {
        return next(new ErrorHandler("User already exists", 400));
      }
      user = await User.create({
        first_name: first_name,
        last_name: last_name,
        full_name: full_name,
        email_address: email_address,
        password: password,
        location: location,
        phone_numbers: phone_numbers,
        role: role,
        gender: gender,
        action: action,
        avatar: avatar
      });
      await Newsletter.create({
        email_address: email_address
      });
      sendToken(user, 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// create admin
router.post(
  "/admin",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { first_name, last_name, email_address, password, location, phone_numbers, role, gender, action, is_activated } = req.body;
      let user = await User.findOne({ email_address });
  
      if (user) {
        return next(new ErrorHandler("User already exists", 400));
      }

      const fullName = `${first_name} ${last_name}`
      user = await User.create({
        first_name: first_name,
        last_name: last_name,
        full_name: fullName,
        email_address: email_address,
        password: password,
        location: location,
        phone_numbers: phone_numbers,
        role: role,
        gender: gender,
        action: action,
        is_activated : is_activated
      });

      try {
        await sendMail({
          email_address: email_address,
          subject: `Création de votre compte de gestion`,
          message: `Bonjour ${fullName}, votre compte de gestion en tant que ${action === 'super' ? 'super adminstrateur' : action} a été crée avec succès. veuillez utiliser vos accès ci-dessous pour vous connecter sur la plateforme de gestion. email: ${email_address} / mot de passe: ${password}.`,
        });
        res.status(200).json({
          success: true,
          message: "Order Refund successfull!",
          user
        });
      } catch (error) {
        return next(new ErrorHandler(error.message, 500));
      }
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// login user
router.post(
  "/login",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { email_address, password } = req.body;

      if (!email_address || !password) {
        return next(new ErrorHandler("Please provide the all fields!", 400));
      }

      const user = await User.findOne({ email_address }).select("+password");

      if (!user) {
        return next(new ErrorHandler("User doesn't exists!", 400));
      }

      const isPasswordValid = await user.comparePassword(password);

      if (!isPasswordValid) {
        return next(
          new ErrorHandler("Please provide the correct information", 400)
        );
      }
      let viewedProducts = [];
      let wishProducts = [];

      await Promise.all(
        user.viewed_list_ids.map(async (id) => {
          const product = await Product.findById(id);
          viewedProducts.push(product)
        })
      )

      await Promise.all(
        user.wish_list_ids.map(async (id) => {
          const product = await Product.findById(id);
          wishProducts.push(product)
        })
      )

      const userData = {
        _id: user._id,
        first_name: user.first_name,
        last_name: user.last_name,
        full_name: user.full_name,
        email_address: user.email_address,
        password: user.password,
        location: user.location,
        phone_numbers: user.phone_numbers,
        role: user.role,
        gender: user.gender,
        action: user.action,
        avatar: user.avatar,
        is_activated: user.is_activated,
        created_at: user.created_at,
        updated_at: user.updated_at,
        created_by: user.created_by,
        updated_by: user.updated_by,
        wish_list_ids: user.wish_list_ids,
        viewed_list_ids: user.viewed_list_ids,
        viewed_products: viewedProducts, 
        wish_products: wishProducts,
        getJwtToken: user.getJwtToken,
        getJwtRefreshToken: user.getJwtRefreshToken
      }

      sendToken(userData, 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// refresh token
router.post(
  "/token",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const {refresh_token} = req.cookies;
      if (!refresh_token) return next(new ErrorHandler("Token does not exist!", 401));
      sendNewToken(refresh_token, 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);


// load user
router.get(
  "/me",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const user = await User.findById(req.user.id).select("+password");

      if (!user) {
        return next(new ErrorHandler("User doesn't exists", 400));
      }

      let viewedProducts = [];
      let wishProducts = [];

      await Promise.all(
        user.viewed_list_ids.map(async (id) => {
          const product = await Product.findById(id);
          viewedProducts.push(product)
        })
      )

      await Promise.all(
        user.wish_list_ids.map(async (id) => {
          const product = await Product.findById(id);
          wishProducts.push(product)
        })
      )

      const userData = {
        _id: user._id,
        first_name: user.first_name,
        last_name: user.last_name,
        full_name: user.full_name,
        email_address: user.email_address,
        password: user.password,
        location: user.location,
        phone_numbers: user.phone_numbers,
        role: user.role,
        gender: user.gender,
        action: user.action,
        avatar: user.avatar,
        is_activated: user.is_activated,
        created_at: user.created_at,
        updated_at: user.updated_at,
        created_by: user.created_by,
        updated_by: user.updated_by,
        wish_list_ids: user.wish_list_ids,
        viewed_list_ids: user.viewed_list_ids,
        viewed_products: viewedProducts, 
        wish_products: wishProducts
      }

      res.status(200).json(userData);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// load user with id
router.get(
  "/profile/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const user = await User.findById(req.params.id).select("+password");

      if (!user) {
        return next(new ErrorHandler("User doesn't exists", 400));
      }

      res.status(200).json(user);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// log out user
router.get(
  "/logout",
  catchAsyncErrors(async (req, res, next) => {
    try {

      res
      .cookie("acces_token", null, {
        expires: new Date(Date.now()),
        httpOnly: true,
        sameSite: "none",
        secure: true,
      })
      .cookie("refresh_token", null, {
        expires: new Date(Date.now()),
        httpOnly: true,
        sameSite: "none",
        secure: true,
      })
      ;
      res.status(201).json('ok');
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update user info
router.put(
  "/me",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { first_name, last_name, email_address, location, phone_numbers, gender } = req.body;

      const user = await User.findOne({ email_address }).select("+password");

      if (!user) {
        return next(new ErrorHandler("User not found", 400));
      }

      const fullName = `${first_name} ${last_name}`;

      user.first_name = first_name; 
      user.last_name = last_name;
      user.full_name = fullName;
      user.location = location; 
      user.phone_numbers = phone_numbers; 
      user.gender = gender; 

      await user.save();

      res.status(201).json({
        success: true,
        user,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update user info with id
router.put(
  "/update/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { first_name, last_name, location, phone_numbers, role, gender, action, is_activated } = req.body;

      const user = await User.findById(req.params.id).select("+password");

      if (!user) {
        return next(new ErrorHandler("User not found", 400));
      }

      const fullName = `${first_name} ${last_name}`;

      user.first_name = first_name; 
      user.last_name = last_name;
      user.full_name = fullName;
      user.location = location; 
      user.phone_numbers = phone_numbers; 
      user.role = role; 
      user.gender = gender; 
      user.action = action; 
      user.is_activated = is_activated; 

      await user.save();

      res.status(201).json({
        success: true,
        user,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update user avatar
router.put(
  "/me/picture",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      let existsUser = await User.findById(req.user.id);
      if (req.body.avatar !== "") {
        
        if(existsUser.avatar) {
          const imageId = existsUser.avatar.public_id;
          await cloudinary.v2.uploader.destroy(imageId); 
        }

        existsUser.avatar = req.body.avatar;
      }

      await existsUser.save();

      res.status(200).json({
        success: true,
        user: existsUser,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update user password
router.put(
  "/me/password",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const user = await User.findById(req.user.id).select("+password");

      const isPasswordMatched = await user.comparePassword(
        req.body.old_password
      );

      if (!isPasswordMatched) {
        return next(new ErrorHandler("Old password is incorrect!", 400));
      }

      if (req.body.password !== req.body.confirm_password) {
        return next(
          new ErrorHandler("Password doesn't matched with each other!", 400)
        );
      }
      user.password = req.body.password;

      await user.save();

      res.status(200).json({
        success: true,
        message: "Password updated successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// forgot my password
router.post("/reset-code", async (req, res, next) => {
  try {
    const { email_address } = req.body;
    const userEmail = await User.findOne({ email_address });

    if (!userEmail) {
      return next(new ErrorHandler("User does not exists", 400));
    }


    const user = {
      email_address: email_address
    };

    const activationToken = createPassChangeToken(user);

    const activationUrl = `${process.env.PORTAL_PORT}/pass-change/${activationToken}`;

    try {
      await sendMail({
        email_address: user.email_address,
        subject: "Réinitialisation de votre compte",
        message: `Bonjour ${userEmail.full_name}, veuillez cliquer sur <a href='${activationUrl}' >le lien</a> suivant pour réinitialiser votre compte: <a href='${activationUrl}' >${activationUrl}</a>`,
      });
      res.status(201).json({
        success: true,
        message: `please check your email.`,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  } catch (error) {
    return next(new ErrorHandler(error.message, 400));
  }
});

// create activation token
const createPassChangeToken = (user) => {
  return jwt.sign(user, process.env.PASS_FORGOT_SECRET, {
    expiresIn: "5m",
  });
};

// activate user
router.post(
  "/change-password",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { change_pass_token } = req.body;

      const existsUser = jwt.verify(
        change_pass_token,
        process.env.PASS_FORGOT_SECRET
      );

      if (!existsUser) {
        return next(new ErrorHandler("Invalid token", 400));
      }

      const { email_address } = existsUser;

      let user = await User.findOne({ email_address });

      if (req.body.password !== req.body.confirm_password) {
        return next(
          new ErrorHandler("Password doesn't matched with each other!", 400)
        );
      }
      user.password = req.body.password;

      await user.save();

      res.status(200).json({
        success: true,
        message: "Password reset successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);


// all users --- for admin
router.get(
  "/all",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      let filter = {};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          created_at: -1,
          _id: 1
        }
      };
      if (req.query.search) {
        filter = {
          ...filter,
          $or: [
            {
              last_name: {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              full_name: {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              first_name: {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              email_address: {
                $regex: new RegExp(req.query.search, 'i')
              }
            }
          ]
        }
      }

      if (req.query.role) {
        filter = {
          ...filter,
          $and: [
            {
              role: req.query.role
            },
          ]
        }
      }
      res.status(201).json(await getItems(User, filter, options));
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// delete users --- admin
router.delete(
  "/delete/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const user = await User.findById(req.params.id);

      if (!user) {
        return next(
          new ErrorHandler("User is not available with this id", 400)
        );
      }

      if(user.avatar) {
        const imageId = user.avatar.public_id;
        await cloudinary.v2.uploader.destroy(imageId); 
      }

      await User.findByIdAndDelete(req.params.id);

      res.status(201).json('ok');
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
