const express = require("express");
const { isAdminCanDo, isAuthenticated, isAdmin } = require("../middleware/auth");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const router = express.Router();
const Blog = require("../model/blog");
const cloudinary = require("cloudinary");
const ErrorHandler = require("../utils/ErrorHandler");
const slugify = require("slugify");
const { getItems } = require("../utils/getItems");

// create blog
router.post(
  "/",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      
        req.body.created_by = req.user._id;
        const blogData = req.body;
        blogData.slug = slugify(req.body.title);

        const blog = await Blog.create(blogData);

        res.status(201).json(blog);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// update blog
router.put(
  "/update/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const {
        title,
        video_url,
        description,
        active,
        with_video,
        video_duration,
        read_duration,
        image,
        large_image
    }  = req.body;

      const blog = await Blog.findById(req.params.id);

      if (!blog) {
        return next(new ErrorHandler("Brand not found with this id", 400));
      }

      

      blog.title = title;
      blog.video_url = video_url;
      blog.description = description;
      blog.active = active;
      blog.with_video = with_video;
      blog.video_duration = video_duration;
      blog.image = image;
      blog.large_image = large_image;
      blog.slug = slugify(title);
      blog.updated_by = req.user._id;

      await blog.save({ validateBeforeSave: false });
      res.status(201).json(blog);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// delete blog
router.delete(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const blog = await Blog.findById(req.params.id);

      if (!blog) {
        return next(new ErrorHandler("Blog is not found with this id", 404));
      }    

      if (blog.image) {
        const result = await cloudinary.v2.uploader.destroy(
          blog.image.public_id
        );
      }
      
      if (blog.large_image) {
        const result = await cloudinary.v2.uploader.destroy(
          blog.large_image.public_id
        );
      }
    
      await blog.deleteOne();

      res.status(201).json({
        success: true,
        message: "Blog Deleted successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// delete blog image
router.delete(
  "/picture/:id/image/:publicId",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const blog = await Blog.findById(req.params.id);

      if (!blog) {
        return next(new ErrorHandler("Blog is not found with this id", 404));
      }

      const result = await cloudinary.v2.uploader.destroy(
        req.params.publicId
      );

    
      blog.image = null;
      blog.updated_by = req.user._id;
      await blog.save({ validateBeforeSave: false });

      res.status(201).json(blog);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);


// get all blogs admins
router.get(
  "/admin",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const filter = {};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          active: 1,
          created_at: -1
        }
      };

      
      res.status(201).json(await getItems(Blog, filter, options));
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);


// get all blogs
router.get(
  "/all",
  catchAsyncErrors(async (req, res, next) => {
    try {

      const filter = {active: true};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          created_at: -1,
          viewed_nb: -1,
          _id: 1
        }
      };
      const blogs = await getItems(Blog, filter, options)
      blogs.results.forEach(blog => {
        let likedByUser = false;
        if(req.user._id) {
          likedByUser = blog.likes.find(
            (rev) => rev.user._id === req.user._id
          );
        }
        blog.is_liked_by_user = likedByUser
      })

      res.status(201).json(blogs);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get blog by id
router.get(
  "/detailed/:id",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const blog = await Blog.findById(req.params.id);

      if (!blog) {
        return next(new ErrorHandler("Blog doesn't exists", 400));
      }
      let likedByUser = false;
      if(req.user._id) {
        likedByUser = blog.likes.find(
          (rev) => rev.user._id === req.user._id
        );
      }

      res.status(200).json({...blog, is_liked_by_user: likedByUser});
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// view a blog
router.put(
  "/view/:id",
  catchAsyncErrors(async (req, res, next) => {
    try {
      
      await Blog.findByIdAndUpdate(
        req.params.id,
        {
          $inc: { viewed_nb: 1 },
        },
        {
          new: true,
        }
      )
      
      res.status(200).json({
        success: true,
        message: "Ok!",
      });
      
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// like a blog
router.put(
  "/like/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { user } = req.body;

      const blog = await Blog.findById(req.params.id);
      const alreadyliked = blog.likes.find(
        (rev) => rev.user._id === req.user._id
      );

      let likeNumber = blog.likes_nb;

      if(alreadyliked) {
        await Blog.findByIdAndUpdate(
          req.params.id,
          {
            $pull: { likes: {"user._id": req.user._id} }
          },
          {
            new: true,
          }
        )
        likeNumber = likeNumber - 1;
      }else {
        const myLike = {
          user,
          created_at: Date.now()
        };
        await Blog.findByIdAndUpdate(
          req.params.id,
          {
            $push: { likes: myLike },
          },
          {
            new: true,
          }
        )
        likeNumber = likeNumber + 1;
      }

      

      blog.likes_nb = likeNumber;

      await blog.save({ validateBeforeSave: false });

      res.status(200).json(blog);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// review a blog
router.put(
  "/review/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { user, comment } = req.body;

      const blog = await Blog.findById(req.params.id);

      const review = {
        user,
        comment,
        blog_id: req.params.id,
      };

      blog.reviews.push(review);

      await blog.save({ validateBeforeSave: false });

      res.status(200).json(blog);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

module.exports = router;

