const express = require("express");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/ErrorHandler");
const router = express.Router();
const multer = require('multer');
const fs = require('fs');
const cloudinary = require("cloudinary");
const upload = multer({ dest: 'uploads/', limits: { fileSize: 1 * 1024 * 1024 } });

// create image
router.post(
  "/:folder",
  upload.single('file'),
  catchAsyncErrors(async (req, res, next) => {
     try {
      const myCloud = await cloudinary.v2.uploader.upload(req.file.path, {
        folder: req.params.folder ?? "allpics",
      });

      fs.unlinkSync(`uploads/${req.file.filename}`)

      res.status(201).json({
        public_id: myCloud.public_id,
        url: myCloud.secure_url,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// delete image
router.delete(
  "/",
  catchAsyncErrors(async (req, res, next) => {
    try {

        const {publicId} = req.body;
      
      const result = await cloudinary.v2.uploader.destroy(
        publicId
      );
      
        res.status(201).json('ok');
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

module.exports = router;
