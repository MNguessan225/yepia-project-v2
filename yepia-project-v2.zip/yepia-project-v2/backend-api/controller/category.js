const express = require("express");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/ErrorHandler");
const { isAdmin, isAdminCanDo, isAuthenticated } = require("../middleware/auth");
const Category = require("../model/category");
const router = express.Router();
const slugify = require("slugify");
const { getItems } = require("../utils/getItems");
// create category
router.post(
  "/",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {

      const { name, category_level_two, category_level_three } = req.body;
      const isCategoryExists = await Category.findOne({
        name: req.body.name,
      });

      if (isCategoryExists) {
        return next(new ErrorHandler("Category already exists!", 400));
      }

      const categoryLevelTwo = [];
      const categoryLevelThree = [];
      for (let i = 0; i < category_level_two.length; i++) {
        category_level_two[i].slug = slugify(category_level_two[i].name);
        categoryLevelTwo.push(category_level_two[i])
      }

      for (let i = 0; i < category_level_three.length; i++) {
        category_level_three[i].slug = slugify(category_level_three[i].name);
        categoryLevelThree.push(category_level_three[i])
      }

      req.body.slug = slugify(req.body.name);
      req.body.category_level_two = categoryLevelTwo;
      req.body.category_level_three = categoryLevelThree;
      req.body.created_by = req.user._id;
      
      const category = await Category.create(req.body);

      res.status(201).json(category);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// update category
router.put(
  "/update/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { name, category_level_two, category_level_three } = req.body;

      const category = await Category.findById(req.params.id);

      if (!category) {
        return next(new ErrorHandler("Category not found", 400));
      }

      const categoryLevelTwo = [];
      const categoryLevelThree = [];
      for (let i = 0; i < category_level_two.length; i++) {
        category_level_two[i].slug = slugify(category_level_two[i].name);
        categoryLevelTwo.push(category_level_two[i])
      }

      for (let i = 0; i < category_level_three.length; i++) {
        category_level_three[i].slug = slugify(category_level_three[i].name);
        categoryLevelThree.push(category_level_three[i])
      }

      category.name = name;
      category.category_level_two = categoryLevelTwo;
      category.category_level_three = categoryLevelThree;
      category.updated_by = req.user._id;

      await category.save();

      res.status(201).json(category);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// delete category
router.delete(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const category = await Category.findByIdAndDelete(req.params.id);

      if (!category) {
        return next(new ErrorHandler("Category dosen't exists!", 400));
      }
      res.status(201).json({
        success: true,
        message: "Category deleted successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get all categories
router.get(
  "/",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const filter = {};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          created_at: -1,
          _id: 1
        }
      };
      res.status(201).json(await getItems(Category, filter, options));
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);


// load category with id
router.get(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const category = await Category.findById(req.params.id);

      if (!category) {
        return next(new ErrorHandler("category doesn't exists", 400));
      }

      res.status(200).json(category);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
