const express = require("express");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/ErrorHandler");
const { isAdmin, isAdminCanDo, isAuthenticated } = require("../middleware/auth");
const Newsletter = require("../model/newsletter");
const { getItems } = require("../utils/getItems");
const router = express.Router();

// create newsletter
router.post(
  "/",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const isNewsletterExists = await Newsletter.findOne({
        email_address: req.body.email_address
      });

      if (isNewsletterExists) {
        

        if(isNewsletterExists.is_activated === true) {
          return next(new ErrorHandler("Vous avez déjà souscrit!", 400));
        }else {
          isNewsletterExists.is_activated = true;

          await isNewsletterExists.save({ validateBeforeSave: false });
          res.status(201).json({
            success: true,
            isNewsletterExists,
          });
        }
      }

      const newsletter = await Newsletter.create(req.body);

      res.status(201).json({
        success: true,
        newsletter,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// cancel newsletter
router.put(
  "/cancel/:email_address",
  catchAsyncErrors(async (req, res, next) => {
    try {

      const newsletter = await Newsletter.findOne({email_address: email_address, is_activated: true});

      if (!newsletter) {
        return next(new ErrorHandler("Newsletter not found with this email address", 400));
      }

      newsletter.is_activated = false;
      
      await newsletter.save({ validateBeforeSave: false });
      res.status(201).json({
        success: true,
        newsletter,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get all newsletters
router.get(
  "/",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      let filter = {};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          created_at: -1,
          _id: 1
        }
      };

      res.status(201).json(await getItems(Newsletter, filter, options));
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
