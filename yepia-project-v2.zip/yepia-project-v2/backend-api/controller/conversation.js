const Conversation = require("../model/conversation");
const ErrorHandler = require("../utils/ErrorHandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const express = require("express");
const { isAuthenticated, isAdmin, isAdminCanDo } = require("../middleware/auth");
const { getItems } = require("../utils/getItems");
const { receiveMail } = require("../utils/sendMail");
const User = require("../model/user");
const router = express.Router();

// create a new conversation
router.post(
  "/",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { group_title, user_id } = req.body;

      const isConversationExist = await Conversation.findOne({ group_title });

      if (isConversationExist) {
        const conversation = isConversationExist;
        res.status(201).json(conversation);
      } else {
        const conversation = await Conversation.create({
          members: [user_id, -1],
          group_title: group_title,
          created_by: req.user._id
        });

        const user = await User.findById(user_id).select("+password");

        try {
          await receiveMail({
            email_address: user.email_address,
            subject: "Nouvelle discussion",
            message: `Bonjour, ${user.full_name} vient de créer une conversation.`,
          });
          res.status(201).json(conversation);
        } catch (error) {
          return next(new ErrorHandler(error.message, 500));
        }

        
      }
    } catch (error) {
      return next(new ErrorHandler(error.response.message), 500);
    }
  })
);

// get all admin conversations
router.get(
  "/admin/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "chat-manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const filter = {
        members: {
          $in: [req.params.id],
        },
      };  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          updated_at: -1,
          created_at: -1
        }
      };
      res.status(201).json(await getItems(Conversation, filter, options));
    } catch (error) {
      return next(new ErrorHandler(error), 500);
    }
  })
);


// get user conversations
router.get(
  "/user/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const conversations = await Conversation.find({
        members: {
          $in: [req.params.id],
        },
      }).sort({ updated_at: -1, created_at: -1 });

      res.status(201).json({
        success: true,
        conversations,
      });
    } catch (error) {
      return next(new ErrorHandler(error), 500);
    }
  })
);

// update the last message
router.put(
  "/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { last_message, last_message_id } = req.body;

      const conversation = await Conversation.findByIdAndUpdate(req.params.id, {
        last_message,
        last_message_id,
        updated_by: req.user._id
      });

      res.status(201).json({
        success: true,
        conversation,
      });
    } catch (error) {
      return next(new ErrorHandler(error), 500);
    }
  })
);

module.exports = router;
