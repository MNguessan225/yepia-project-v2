const express = require("express");
const router = express.Router();
const ErrorHandler = require("../utils/ErrorHandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const { isAuthenticated, isAdmin, isAdminCanDo } = require("../middleware/auth");
const Order = require("../model/order");
const Product = require("../model/product");
const Withdraw = require("../model/withdraw");
const { receiveMail, sendMail } = require("../utils/sendMail");
const User = require("../model/user");
const { getItems } = require("../utils/getItems");

// create new order
router.post(
  "/",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { cart, shipping_address, user, total_price, shipping_cost } = req.body;

      const order = await Order.create({
        cart,
        shipping_address,
        shipping_cost,
        user: req.user,
        total_price,
        tracking: [
          {
            action : 'order-created',
            by: req.user._id,
            date: Date.now()
          }
        ]
      });

      try {
        await sendMail({
          email_address: req.user.email_address,
          subject: "Nouvelle commande",
          message: `Bonjour ${req.user.full_name} votre nouvelle commande <strong>N°${order?._id}</strong> a été créer avec succès. Nos équipes s'occupent de vous la livrer. `,
        });
        await receiveMail({
          email_address: req.user.email_address,
          subject: "Nouvelle commande",
          message: `Bonjour, ${req.user.full_name} vient de créer une commande.`,
        });
        res.status(201).json({
          success: true,
          order,
        });
      } catch (error) {
        return next(new ErrorHandler(error.message, 500));
      }
      
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// get all orders of user
router.get(
  "/user/:email_address",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {"user.email_address": req.params.email_address};  // Apply your custom filter here
      let options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          delivered_at: -1,
          created_at: -1,
          _id: 1
        }
      };

      const itemsPaginated = await getItems(Order, filter, options)

      res.status(200).json(itemsPaginated);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// get all orders of admin
router.get(
  "/admin",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "order-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      let filter = {};  // Apply your custom filter here
      let options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          delivered_at: -1,
          created_at: -1,
          _id: 1
        }
      };

      if (req.query.search) {
        filter = {
          ...filter,
          $or: [
            {
              _id: req.query.search
            },
            {
              "user.full_name": {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              "user.first_name": {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              "user.email_address": {
                $regex: new RegExp(req.query.search, 'i')
              }
            }
          ]
        }
      }

      const itemsPaginated = await getItems(Order, filter, options)

      res.status(200).json(itemsPaginated);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// get all orders of admin deliveries
router.get(
  "/deliveries",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "order-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      

      let filter = { status: { $in: ['processing', 'shipping', 'not-delivered', 'delivered'] } };  // Apply your custom filter here
      let options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          delivered_at: -1,
          created_at: -1,
          _id: 1
        }
      };

      if (req.query.search) {
        filter = {
          ...filter,
          $or: [
            {
              _id: req.query.search
            },
            {
              "user.full_name": {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              "user.first_name": {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              "user.email_address": {
                $regex: new RegExp(req.query.search, 'i')
              }
            }
          ]
        }
      }

      const itemsPaginated = await getItems(Order, filter, options)

      res.status(200).json(itemsPaginated);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// get all orders of admin returns
router.get(
  "/returns",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "order-checker", "retourn-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      

      let filter = { status: { $in: ['refund-request', 'refunded'] } };  // Apply your custom filter here
      let options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          delivered_at: -1,
          created_at: -1,
          _id: 1
        }
      };

      if (req.query.search) {
        filter = {
          ...filter,
          $or: [
            {
              _id: req.query.search
            },
            {
              "user.full_name": {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              "user.first_name": {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              "user.email_address": {
                $regex: new RegExp(req.query.search, 'i')
              }
            }
          ]
        }
      }

      const itemsPaginated = await getItems(Order, filter, options)

      res.status(200).json(itemsPaginated);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// get order by id
router.get(
  "/detailed/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const order = await Order.findById(req.params.id);

      if (!order) {
        return next(new ErrorHandler("Order doesn't exists", 400));
      }

      res.status(200).json(order);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// get all orders of deliveryman
router.get(
  "/delivery/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "deliveryman"]),
  catchAsyncErrors(async (req, res, next) => {
    try {

      let filter = {"assigned_to._id": req.params.id};  // Apply your custom filter here
      let options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          delivered_at: -1,
          created_at: -1,
          _id: 1
        }
      };

      if (req.query.search) {
        filter = {
          ...filter,
          $or: [
            {
              _id: req.query.search
            },
            {
              "user.full_name": {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              "user.first_name": {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
            {
              "user.email_address": {
                $regex: new RegExp(req.query.search, 'i')
              }
            }
          ]
        }
      }

      const itemsPaginated = await getItems(Order, filter, options)
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//Assign order to a deliveryman
router.put(
  "/assign/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const order = await Order.findById(req.params.id);

      if (!order) {
        return next(new ErrorHandler("Order not found with this id", 400));
      }
      
      const user = await User.findById(req.body.assigned_to?.value);

      order.assigned_to = user;
      order.status = 'processing';
      order.updated_by = req.user._id;
      order.tracking = [...order.tracking, {
        action : 'order-assigned-to-delivery',
        by: req.user._id,
        date: Date.now()
      }];

      await order.save({ validateBeforeSave: false });
      
      try {
        await sendMail({
          email_address: user.email_address,
          subject: "Nouvelle commande assignées",
          message: `Bonjour ${user.full_name} vous avez une nouvelle commande à livrer.`,
        });
        res.status(200).json({
          success: true,
          order,
        });
      } catch (error) {
        return next(new ErrorHandler(error.message, 500));
      }
      
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update order status for user
router.put(
  "/user/status/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const order = await Order.findById(req.params.id);

      if (!order) {
        return next(new ErrorHandler("Order not found with this id", 400));
      }
      if (req.body.status !== "cancelled") {
        return next(new ErrorHandler("You can't make this action", 400));
      }

      order.status = req.body.status;
      order.tracking = [...order.tracking, {
        action : 'order-cancelled',
        by: req.user._id,
        date: Date.now()
      }];
      order.updated_by = req.user._id;

      await order.save({ validateBeforeSave: false });

      try {
        await receiveMail({
          email_address: order.user.email_address,
          subject: "Commande annulée",
          message: `Bonjour, ${order.user.full_name} vient d'annuler sa commande N°${req.params.id}`,
        });
        res.status(201).json({
          success: true,
          order,
        });
      } catch (error) {
        return next(new ErrorHandler(error.message, 500));
      }
      
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update order status for admin
router.put(
  "/admin/status/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "order-checker", "deliveryman", "order-checker", "retourn-manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const order = await Order.findById(req.params.id);

      if (!order) {
        return next(new ErrorHandler("Order not found with this id", 400));
      }

      order.status = req.body.status;

      if (req.body.status === "delivered") {
        order.delivered_at = Date.now();
        order.failed_delivery_note = null;

        order.cart.forEach(async (o) => {
          await updateOrder(o._id, o.qty);
        });

        const withdrawData = {
          orderId: req.params.id,
          amount: order.total_price,
          created_by: req.user._id
        }

        await Withdraw.create(withdrawData);

      }

      if (req.body.status === "not-delivered") {
        order.failed_delivery_note = req.body.failed_delivery_note;
      }

      order.tracking = [...order.tracking, {
        action : req.body.status === 'processing' ? 'order-accepted' : req.body.status === 'shipping' ? 'order-shipping': req.body.status === 'not-delivered' ? 'order-aborted': req.body.status === 'delivered' ? 'order-delivered': req.body.status === 'refund-request' ? 'order-refund-requested': 'refunded',
        by: req.user._id,
        date: Date.now()
      }];
      order.updated_by = req.user._id;

      await order.save({ validateBeforeSave: false });

      let message = "";
      let subject = "";

      switch (req.body.status) {
        case "processing":
          subject = `Commande N°${req.params.id} traitée`
          message = `Bonjour ${order.user.full_name}, votre commande N°${req.params.id} vient d'être validée par nos équipes, Un livreur s'occupe de votre livraison.`
          break;

        case "shipping":
          subject = `Commande N°${req.params.id} en cours de livraison`
          message = `Bonjour ${order.user.full_name}, notre livreur est en chemin pour vous livrer votre commande N°${req.params.id}.`
          break;
        case "not-delivered":
          subject = `Commande N°${req.params.id}: Erreur de livraison`
          message = `Bonjour ${order.user.full_name}, notre livreur n'a pas pu vous livrer votre commande N°${req.params.id} en raison de: ${req.body.notes}. Merci de contacter nos équipes dans les plus brefs délais, afin de vous livrer votre commande.`
          break;
        case "delivered":
          subject = `Commande N°${req.params.id} livrée avec succès!`
          message = `Bonjour ${order.user.full_name}, votre commande N°${req.params.id} a été livrée avec succès. Merci d'avoir fait confiance à Yepia. Nous serons ravis de vous livrer d'autres commandes.`
          break;
      
        default:
          break;
      }
      
      try {
        await sendMail({
          email_address: order.user.email_address,
          subject: subject,
          message: message,
        });
        res.status(200).json({
          success: true,
          order,
        });
      } catch (error) {
        return next(new ErrorHandler(error.message, 500));
      }

      async function updateOrder(id, qty) {
        const product = await Product.findById(id);

        product.stock -= qty;
        product.sold_out += qty;

        await product.save({ validateBeforeSave: false });
      }

    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// give a refund ----- user
router.put(
  "/refund-request/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const order = await Order.findById(req.params.id);

      if (!order) {
        return next(new ErrorHandler("Order not found with this id", 400));
      }

      if (order.status !== 'delivered') {
        return next(new ErrorHandler("Cette commande ne peut être soumise à un retour", 400));
      }

      order.status = req.body.status;

      order.tracking = [...order.tracking, {
        action: 'refund-request',
        by: req.user._id,
        date: Date.now()
      }];
      order.updated_by = req.user._id;
      await order.save({ validateBeforeSave: false });
      try {
        await sendMail({
          email_address: order.user.email_address,
          subject: `Retour de la commande N°${order?._id}`,
          message: `Bonjour ${order.user.full_name}, afin de procéder au remboursement de votre commande <strong>N°${order?._id}</strong>, merci de vous rendre dans nos locaux.`,
        });
        await receiveMail({
          email_address: order.user.email_address,
          subject: "Processus de retour de commande",
          message: `Bonjour, ${order.user.full_name} vient d'émettre une requête de retour de sa commande <strong>N°${req.params.id}</strong>`,
        });
        res.status(200).json({
          success: true,
          order,
          message: "Order Refund Request successfully!",
        });
      } catch (error) {
        return next(new ErrorHandler(error.message, 500));
      }
      
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// accept the refund ---- seller
router.put(
  "/refund-process/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "retourn-manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const order = await Order.findById(req.params.id);

      if (!order) {
        return next(new ErrorHandler("Order not found with this id", 400));
      }

      if (req.body.status === "accepted") {
        order.cart.forEach(async (o) => {
          await updateOrder(o._id, o.qty);
        });

        order.status = 'refunded';
        order.tracking = [...order.tracking, {
          action: 'refunded',
          by: req.user._id,
          date: Date.now()
        }];
        order.not_refunded_note = null
        order.updated_by = req.user._id;

        const withdrawData = await Withdraw.findOne({
          orderId: req.params.id
        })
        withdrawData.status = 'refunded';
        withdrawData.amount = -withdrawData.amount;
        withdrawData.updated_by = req.user._id;
        withdrawData.updated_at = Date.now();

        await Withdraw.create(withdrawData);

        await order.save();

        try {
          await sendMail({
            email_address: order.user.email_address,
            subject: `Retour de la commande N°${order?._id} approuvée`,
            message: `Bonjour ${order.user.full_name}, votre demande de remboursement de votre commande <strong>N°${order?._id}</strong> vient d'être approuvée. Merci de toujours faire confiance à Yepia`,
          });
          res.status(200).json({
            success: true,
            message: "Order Refund successfull!",
          });
        } catch (error) {
          return next(new ErrorHandler(error.message, 500));
        }
      }else {
        order.status = 'delivered';

        order.tracking = [...order.tracking, {
          action: 'refund-not-validated',
          by: req.user._id,
          date: Date.now()
        }];
        order.updated_by = req.user._id;
        order.not_refunded_note = req.body.not_refunded_note;
        await order.save();

        try {
          await sendMail({
            email_address: order.user.email_address,
            subject: `Demande de retour de la commande N°${order?._id} non approuvée`,
            message: `Bonjour ${order.user.full_name}, Nous ne pouvons approuvée votre demande de remboursement pour votre commande <strong>N°${order?._id}</strong>. Merci de vous rendre dans nos locaux pour plus de reclamations`,
          });
          res.status(200).json({
            success: true,
            message: "Order Refund request cancelled!",
          });
        } catch (error) {
          return next(new ErrorHandler(error.message, 500));
        }
      }


      async function updateOrder(id, qty) {
        const product = await Product.findById(id);

        product.stock += qty;
        product.sold_out -= qty;

        await product.save({ validateBeforeSave: false });
      }
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
