const express = require("express");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/ErrorHandler");
const { isAdmin, isAdminCanDo, isAuthenticated } = require("../middleware/auth");
const Brand = require("../model/brand");
const { getItems } = require("../utils/getItems");
const router = express.Router();

// create brand
router.post(
  "/",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const isBrandExists = await Brand.findOne({
        name: req.body.name,
      });

      if (isBrandExists) {
        return next(new ErrorHandler("Brand already exists!", 400));
      }
      req.body.created_by = req.user._id;
      const brand = await Brand.create(req.body);

      res.status(201).json(brand);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// update brand
router.put(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { name } = req.body;

      const brand = await Brand.findById(req.params.id);

      if (!brand) {
        return next(new ErrorHandler("Brand not found with this id", 400));
      }

      brand.name = name;
      brand.updated_by = req.user._id;
      
      await brand.save({ validateBeforeSave: false });
      res.status(201).json(brand);
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// delete brand
router.delete(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const brand = await Brand.findByIdAndDelete(req.params.id);

      if (!brand) {
        return next(new ErrorHandler("Brand dosen't exists!", 400));
      }
      res.status(201).json({
        success: true,
        message: "Brand deleted successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

// get all brands
router.get(
  "/",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager", "product-checker"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      let filter = {};  // Apply your custom filter here
      const options = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: {
          created_at: -1,
          _id: 1
        }
      };

      if (req.query.search) {
        filter = {
          $or: [
            {
              name: {
                $regex: new RegExp(req.query.search, 'i')
              }
            },
          ]
        }
      }
      res.status(201).json(await getItems(Brand, filter, options));
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);


// load brand with id
router.get(
  "/:id",
  isAuthenticated,
  isAdmin("admin"),
  isAdminCanDo(["super", "manager"]),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const brand = await Brand.findById(req.params.id);

      if (!brand) {
        return next(new ErrorHandler("brand doesn't exists", 400));
      }

      res.status(200).json(brand);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
