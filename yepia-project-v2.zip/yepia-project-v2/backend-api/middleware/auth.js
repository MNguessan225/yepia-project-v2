const ErrorHandler = require("../utils/ErrorHandler");
const catchAsyncErrors = require("./catchAsyncErrors");
const jwt = require("jsonwebtoken");
const User = require("../model/user");

exports.isAuthenticated = catchAsyncErrors(async(req,res,next) => {
    const {acces_token} = req.cookies;

    if(!acces_token){
        return next(new ErrorHandler("Token does not exists anymore", 401));
    }

    jwt.verify(acces_token, process.env.JWT_SECRET_KEY, async (err, user) => {
        if (err) return next(new ErrorHandler("Token expired, please log again", 403));
        req.user = await User.findById(user.id);
        next();
    });
});


exports.isAdmin = (...roles) => {
    return (req,res,next) => {
        if(!roles.includes(req.user.role)){
            return next(new ErrorHandler(`${req.user.role} can not access this resources!`))
        };
        next();
    }
}

exports.isAdminCanDo = (action) => {
    const _actions = [...action]
    
    return (req,res,next) => {
        if(!_actions.includes(req.user.action)){
            return next(new ErrorHandler(`${req.user.action} can not access this resources!`))
        };
        next();
    }
}