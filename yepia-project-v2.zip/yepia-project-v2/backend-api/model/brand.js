const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const brandSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please enter your brand name!"],
    trim: true
  },
  created_at: {
    type: Date,
    default: Date.now()
  },
  updated_at: {
    type: Date,
    default: Date.now()
  },
  created_by: {
    type: String,
    default: '-1'
  },
  updated_by: {
    type: String,
    default: '-1'
  },
});

// When save
brandSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

brandSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Brand", brandSchema);
