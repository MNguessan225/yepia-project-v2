const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const messagesSchema = new mongoose.Schema(
  {
    conversation_id: {
      type: String,
    },
    text: {
      type: String,
    },
    sender: {
      type: String,
    },
    images: {
      public_id: {
        type: String,
      },
      url: {
        type: String,
      },
    },
    created_at: {
      type: Date,
      default: Date.now()
    }
  },
  { timestamps: true }
);

messagesSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Messages", messagesSchema);
