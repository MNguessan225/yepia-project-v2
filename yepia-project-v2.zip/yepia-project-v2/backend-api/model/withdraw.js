const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const withdrawSchema = new mongoose.Schema({
  orderId: {
    type: String,
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  status: {
    type: String,
    enum: ["paid", "refunded"],
    default: "paid",
  },
  created_at: {
    type: Date,
    default: Date.now(),
  },
  updated_at: {
    type: Date,
    default: Date.now(),
  },
  created_by: {
    type: String,
    default: null
  },
  updated_by: {
    type: String,
    default: null
  },
});

withdrawSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Withdraw", withdrawSchema);
