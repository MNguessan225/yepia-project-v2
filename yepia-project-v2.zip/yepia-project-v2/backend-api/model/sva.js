const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');


var svaSchema = new mongoose.Schema(
  {
    device_name: {
      type: String,
      required: [true, "Missing device_name!"],
      trim: true,
    },
    order_id: {
        type: String,
        default: ''
    },
    serial_number: {
      type: String,
      required: [true, "Missing serial_number!"],
      unique: true
    },
    description: {
      type: String,
      maxLength: 1000
    },
    images : [
        {
            public_id: {
                type: String,
            },
            url: {
                type: String,
            },
        }
    ],
    full_name: {
        type: String,
        required: [true, "Missing full_name!"],
    },
    email_address:{
        type: String,
        required: [true, "Missing email_address!"],
        trim: true
    },
    phone_number: {
        type: String,
        required: [true, "Missing phone_number!"],
    },
    is_new: {
      type: Boolean,
      default: true,
    },
    status: {
      type: Number,
      default: 0,
    },
    traited_by: {
        type: Object
    },
    updated_by: {
        type: String,
        default: '-1'
     },
  },
  { timestamps: true }
);

// When save
svaSchema.pre('save', function(next) {
    this.updated_at = Date.now();
    next();
});

svaSchema.plugin(mongoosePaginate);
//Export the model
module.exports = mongoose.model("Sva", svaSchema);
