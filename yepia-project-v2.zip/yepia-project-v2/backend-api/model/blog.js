const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const blogSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Please enter your blog name!"],
    trim: true,
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  image: {
    public_id: {
      type: String,
      required: true,
    },
    url: {
      type: String,
      required: true,
    },
  },
  large_image: {
    public_id: {
      type: String,
      required: true,
    },
    url: {
      type: String,
      required: true,
    },
  },
  video_url: {
    type: String,
    trim: true,
  },
  description: {
    type: String,
    required: [true, "Please enter your blog description!"],
  },
  reviews: [
    {
      user: {
        type: Object,
      },
      comment: {
        type: String,
      },
      blog_id: {
        type: String,
      },
      created_at:{
        type: Date,
        default: Date.now(),
      }
    },
  ],
  likes: [
    {
      user: {
        type: Object,
      },
      created_at:{
        type: Date,
        default: Date.now(),
      }
    },
  ],
  likes_nb: {
    type: Number,
    default: 0,
  },
  active: {
    type: Boolean,
    default: true
  },
  with_video: {
    type: Boolean,
    default: false
  },
  video_duration: {
    type: Number,
    default: 0
  },
  read_duration: {
    type: Number,
    default: 0
  },
  viewed_nb: {
    type: Number,
    default: 0,
  },
  created_at: {
    type: Date,
    default: Date.now(),
  },
  updated_at: {
    type: Date,
    default: Date.now(),
  },
  created_by: {
    type: String,
    default: null
  },
  updated_by: {
    type: String,
    default: null
  },
});

// When save
blogSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

blogSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Blog", blogSchema);
