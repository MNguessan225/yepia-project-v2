const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const orderSchema = new mongoose.Schema({
    cart:{
        type: Array,
        required: true,
    },
    shipping_address:{
        type: {
            full_address: {
              type: String,
              required: [true, "Missing full_address!"],
              trim: true
            },
            city: {
              type: String,
              required: [true, "Missing city!"],
              default: "Abidjan",
              trim: true
            },
            phone_number: {
             type: String,
             trim: true
            },
        },
        required: true,
    },
    user:{
        type: Object,
        required: true,
    },
    shipping_cost:{
        type: Number,
        required: true,
    },
    notes:{
        type: String,
        default: null
    },
    failed_delivery_note:{
        type: String,
        default: null
    },
    not_refunded_note:{
        type: String,
        default: null
    },
    total_price:{
        type: Number,
        required: true,
    },
    status:{
        type: String,
        default: "pending",
        enum: [
            "pending",
            "processing",
            "shipping",
            "refund-request",
            "refunded",
            "cancelled",
            "not-delivered",
            "delivered"
        ],
    },
    delivered_at: {
        type: Date,
        default: null
    },
    tracking: [{
        type: Object
    }],
    assigned_to: {
        type: Object,
        default: null
    },
    created_at: {
        type: Date,
        default: Date.now(),
    },
    updated_at: {
        type: Date,
        default: Date.now(),
    },
    updated_by: {
        type: String,
        default: '-1'
    }
});

// When update with findOneAndUpdate
orderSchema.pre('save', function(next) {
    this.updated_at = Date.now();
    next();
});

orderSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Order", orderSchema);