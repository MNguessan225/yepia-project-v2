const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const roomSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please enter your room name!"],
    trim: true
  },
  location: {
    type: {
      full_address: {
        type: String,
        required: [true, "Missing full_address!"],
        trim: true,
      },
      city: {
        type: String,
        required: [true, "Missing city!"],
        default: "Abidjan",
        trim: true,
      },
      country: {
        type: String,
        default: "Côte d'Ivoire",
        trim: true,
      }, 
      country_flag: {
        type: String,
        default: '🇨🇮'
      },
      coordinates: {
        type: [Number],
        required: [false, "Missing coordinates!"],
        default: [5.345317,-4.024429],
        trim: true,
      }
    },
    default: null
  },
  phone_numbers:{
    type: [String],
    default: null,
    trim: true,
  },
  image: {
    public_id: {
      type: String,
    },
    url: {
      type: String,
    },
  },
  created_at: {
    type: Date,
    default: Date.now()
  },
  updated_at: {
    type: Date,
    default: Date.now()
  },
  created_by: {
    type: String,
    default: '-1'
  },
  updated_by: {
    type: String,
    default: '-1'
  },
});

// When save
roomSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

roomSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Room", roomSchema);
