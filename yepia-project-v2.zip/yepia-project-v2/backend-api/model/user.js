const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const mongoosePaginate = require('mongoose-paginate-v2');

const userSchema = new mongoose.Schema({
  first_name:{
    type: String,
    required: [true, "Missing first_name!"],
    trim: true,
  },
  last_name:{
    type: String,
    required: [true, "Missing last_name!"],
    trim: true,
  },
  full_name:{
    type: String,
    required: [true, "Missing full_name!"],
  },
  email_address:{
    type: String,
    required: [true, "Missing email_address!"],
    trim: true,
    unique: true,
  },
  password:{
    type: String,
    required: [true, "Please enter your password"]
  },
  location: {
    type: {
      full_address: {
        type: String,
        required: [true, "Missing full_address!"],
        trim: true,
      }, 
      city: {
        type: String,
        required: [true, "Missing city!"],
        default: "Abidjan",
        trim: true,
      },
      country: {
        type: String,
        default: "Côte d'Ivoire",
        trim: true,
      }, 
      country_flag: {
        type: String,
        default: '🇨🇮'
      },
      coordinates: {
        type: [Number],
        required: [false, "Missing coordinates!"],
        default: [5.345317,-4.024429],
        trim: true,
      }
    },
    default: null
  },
  phone_numbers:{
    type: [String],
    default: null,
    trim: true,
  },
  role:{
    type: String,
    enum: ["user", "admin"],
    default: "user",
    required: [true, "Missing role"]
  },
  gender:{
    type: String,
    enum: ["man", "woman"],
    default: "man",
    required: [true, "Missing gender"]
  },
  action:{
    type: String,
    enum: ["free", "super", "manager", "deliveryman", "product-checker", "order-checker", "retourn-manager", "chat-manager", "sva-manager"],
    default: "free",
    required: [true, "Missing gender"]
  },
  avatar:{
    type: {
      public_id: {
        type: String,
        required: true,
      },
      url: {
        type: String,
        required: true,
      },
    },
    default: null
 },
 is_activated: {
  type: Boolean,
  default: true,
 },
 created_at: {
  type: Date,
  default: Date.now(),
 },
 updated_at: {
    type: Date,
    default: Date.now(),
 },
 created_by: {
    type: String,
    default: '-1'
 },
 updated_by: {
    type: String,
    default: '-1'
 },
 wish_list_ids: {
    type: [String],
 },
 viewed_list_ids: {
    type: [String],
 },
 resetPasswordToken: String,
 resetPasswordTime: Date,
});

//  Hash password
userSchema.pre("save", async function (next){
  if(!this.isModified("password")){
    next();
  }
  this.password = await bcrypt.hash(this.password, 10);
});

// When update with findOneAndUpdate
userSchema.pre('findOneAndUpdate', function(next) {
  this.updated_at = Date.now();
  next();
});

// When update with findByIdAndUpdate
userSchema.pre('findByIdAndUpdate', function(next) {
  this.updated_at = Date.now();
  next();
});

// When update with updateOne
userSchema.pre('updateOne', function(next) {
  this.updated_at = Date.now();
  next();
});

// jwt token
userSchema.methods.getJwtToken = function () {
  return jwt.sign({ id: this._id}, process.env.JWT_SECRET_KEY,{
    expiresIn: process.env.JWT_EXPIRES,
  });
};

// jwt refreshtoken
userSchema.methods.getJwtRefreshToken = function () {
  return jwt.sign({ id: this._id}, process.env.JWT_REFRESH_SECRET_KEY,{
    expiresIn: process.env.JWT_REFRESH_EXPIRES,
  });
};

// compare password
userSchema.methods.comparePassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

userSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("User", userSchema);
