const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const productSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Please enter your product name!"],
    trim: true,
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  description: {
    type: String,
    required: [true, "Please enter your product description!"],
  },
  specifications: {
    type: String
  },
  category_level_one: {
    type: Object,
    required: true
  },
  category_level_two: {
    type: Object,
    default: null
  },
  category_level_three: {
    type: Object,
    default: null
  },
  brand: {
    type: Object
  },
  model: {
    type: String,
  },
  price: {
    type: Number,
  },
  promotion: {
    type: {
      active: {
        type: Boolean,
        default: true
      },
      cost: {
        type: Number
      },
      start_dt: {
        type: Date,
        default: Date.now(),
      },
      end_dt: {
        type: Date,
        default: Date.now(),
      }
    },
    default: null
  },
  images: [
    {
      public_id: {
        type: String,
        required: true,
      },
      url: {
        type: String,
        required: true,
      },
    },
  ],
  reviews: [
    {
      user: {
        type: Object,
      },
      rating: {
        type: Number,
      },
      comment: {
        type: String,
      },
      product_id: {
        type: String,
      },
      created_at:{
        type: Date,
        default: Date.now(),
      }
    },
  ],
  active: {
    type: Boolean,
    default: true
  },
  status: {
    type: String,
    default: 'in-stock',
    enum: ['in-stock', 'out-stockage']
  },
  ratings: {
    type: Number,
    default: 0,
  },
  sold_out: {
    type: Number,
    default: 0,
  },
  viewed_nb: {
    type: Number,
    default: 0,
  },
  stock: {
    type: Number,
    default: 1,
  },
  created_at: {
    type: Date,
    default: Date.now(),
  },
  updated_at: {
    type: Date,
    default: Date.now(),
  },
  created_by: {
    type: String,
    default: null
  },
  updated_by: {
    type: String,
    default: null
  },
});

// When save
productSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

productSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Product", productSchema);
