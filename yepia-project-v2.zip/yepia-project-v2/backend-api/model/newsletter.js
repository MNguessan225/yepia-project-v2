const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const newsletterSchema = new mongoose.Schema({
  email_address:{
    type: String,
    required: [true, "Missing email_address!"],
    trim: true,
    unique: true,
  },
  is_activated: {
    type: Boolean,
    default: true,
  },
  created_at: {
    type: Date,
    default: Date.now()
  }
});

// When save
newsletterSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

newsletterSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Newsletter", newsletterSchema);
