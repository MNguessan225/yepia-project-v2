const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const conversationSchema = new mongoose.Schema(
  {
    group_title:{
        type: String,
    },
    members: {
      type: Array,
    },
    last_message: {
      type: String,
    },
    last_message_id: {
      type: String,
    },
    created_at: {
      type: Date,
      default: Date.now(),
    },
    updated_at: {
      type: Date,
      default: Date.now(),
    },
    created_by: {
      type: String,
      default: '-1'
    },
    updated_by: {
      type: String,
      default: '-1'
    }
  },
  { timestamps: true }
);

// When update with findByIdAndUpdate
conversationSchema.pre('findByIdAndUpdate', function(next) {
  this.updated_at = Date.now();
  next();
});


conversationSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Conversation", conversationSchema);
