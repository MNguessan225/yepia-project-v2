const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const coupounCodeSchema = new mongoose.Schema({
    name:{
        type: String,
        required:[true,"Please enter your coupoun code name!"],
        unique: true,
    },
    value:{
        type: Number,
        required: true,
    },
    min_amount:{
        type: Number,
    },
    max_amount:{
        type: Number,
    },
    selected_product:{
     type: String,
    },
    created_at: {
        type: Date,
        default: Date.now(),
    },
    updated_at: {
        type: Date,
        default: Date.now(),
    },
    created_by: {
        type: String,
        default: '-1'
    },
    updated_by: {
        type: String,
        default: '-1'
    }
});

// When save
coupounCodeSchema.pre('save', function(next) {
    this.updated_at = Date.now();
    next();
});

coupounCodeSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("CoupounCode", coupounCodeSchema);