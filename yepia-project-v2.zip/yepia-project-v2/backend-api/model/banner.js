const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const bannerSchema = new mongoose.Schema({
  link: {
    type: String,
    required: [true, "Please enter your banner link!"],
    trim: true
  },
  image: {
    public_id: {
      type: String,
    },
    url: {
      type: String,
    },
  },
  position:{
    type: String,
    enum: ["firts_bann_right", "first_bann_left", "full_bann", "stock_1", "stock_2", "stock_3", "stock_4"],
    default: "firts_bann_right",
    required: [true, "Missing position"]
  },
  created_at: {
    type: Date,
    default: Date.now()
  },
  updated_at: {
    type: Date,
    default: Date.now()
  },
  created_by: {
    type: String,
    default: '-1'
  },
  updated_by: {
    type: String,
    default: '-1'
  },
});

// When save
bannerSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

bannerSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Banner", bannerSchema);
