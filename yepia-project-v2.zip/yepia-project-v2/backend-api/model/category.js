const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');

const categorySchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please enter your category name!"],
    trim: true,
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  category_level_two: {
    type: [
      {
        name: {
          type: String,
          required: [true, "Please enter your category_level_two name!"],
          trim: true,
        },
        slug: {
          type: String,
          required: true,
          lowercase: true
        }
      }
    ],
    default: []
  },
  category_level_three: {
    type: [
      {
        name: {
          type: String,
          required: [true, "Please enter your category name!"],
          trim: true,
        },
        slug: {
          type: String,
          required: true,
          lowercase: true
        }
      }
    ],
    default: []
  },
  clicks_nb: {
    type: Number,
    default: 0,
  },
  created_at: {
    type: Date,
    default: Date.now(),
  },
  updated_at: {
    type: Date,
    default: Date.now(),
  },
  created_by: {
    type: String,
    default: '-1'
  },
  updated_by: {
    type: String,
    default: '-1'
  }
});

// When save
categorySchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

categorySchema.plugin(mongoosePaginate);
module.exports = mongoose.model("Category", categorySchema);
