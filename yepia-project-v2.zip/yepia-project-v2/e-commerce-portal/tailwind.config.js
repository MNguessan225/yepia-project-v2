/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {},
    screens: {
      width500: '500px', 
      width350: '350px',
      width390: '390px',
      width375: '375px',
      smallScreen: '450px',
      treffPunkTeSize: '570px',
      width650: '650px',
      width600: '600px',
      tablet: '640px',
      // => @media (min-width: 640px) { ... }
      bigTablet: '769px',
      // => @media (min-width: 640px) { ... }
      sizeForSelectItem: '790px',
      // => @media (min-width: 640px) { ... }

      laptop: '1024px',
      // => @media (min-width: 1024px) { ... }
      bigLaptop: '1200px',
      desktop: '1280px',
      desktopSize: '1290px',
      // => @media (min-width: 1280px) { ... }

      otherWidth: '1135px',
      // => @media (min-width: 1280px) { ... }
      largeSize: '1440px',
      // => @media (min-width: 1280px) { ... }
      miniLaptop: '992px', 
      // => @media (min-width: 1280px) { ... }
      smallLaptop: '850px',
      // => @media (min-width: 1280px) { ... }

      width1100: '1100px',
      // => @media (min-width: 1100px) { ... }
      size1440: '1440px',
      // => @media (min-width: 1440px) { ... }
      largeSize1441: '1441px',
      // => @media (min-width: 1441px) { ... }
    },
  },
  plugins: [],
}

