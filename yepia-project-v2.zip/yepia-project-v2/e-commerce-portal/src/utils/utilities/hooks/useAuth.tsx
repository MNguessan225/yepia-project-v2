import React, { useEffect, useContext } from 'react';
import { AuthContext } from '../../../context/auth';
import { Client, types } from '../../../sdks/auth-v1';
import { API_SERVER } from '../constants';

const client = new Client();

const useAuth = () => {
    const { signOut } = useContext(AuthContext);

    useEffect(() => {
        (async () => {

            client.configure({
                baseURL: API_SERVER,
                signOut
            })

        })()
    }, [])

    return { client, types }
}

export default useAuth;