import * as heic2any from 'heic2any';

export async function convertHEICToJPEG_(blob: any): Promise<Blob> {
    const newBlob: any = await heic2any.default({ blob: blob, toType: "image/jpeg", quality: 1 })

    const blobTemp: any = new Blob([newBlob], { type: 'image/jpeg' })

    if (blob?.name?.includes("heic")) {
        blobTemp.name = blob?.name?.replace("heic", "jpeg");
        blobTemp.filename = blob?.name?.replace("heic", "jpeg");
    } else if (blob?.name?.includes("HEIC")) {
        blobTemp.name = blob?.name?.replace("HEIC", "jpeg");
        blobTemp.filename = blob?.name?.replace("HEIC", "jpeg");
    }

    return blobTemp
}

export async function convertHEICToJPEG(blob: any): Promise<any> {
    try {
        return await convertHEICToJPEG_(blob)
    } catch (error) {
        if ((error as any)?.code === 1 && (error as any)?.message?.includes("image/jpeg")) {
            return blob
        } else {
            throw error
        }
    }
}