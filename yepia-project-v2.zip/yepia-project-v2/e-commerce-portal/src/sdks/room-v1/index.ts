// eslint-disable-next-line no-unused-vars
import * as dataSchemas from './utils/DataSchemas'

import API from './config'
import Service from './services'
import { Options } from '../../api/DataSchemas'
import { Pagination, PaginationOption } from '../GlobalDataSchemas'

const objectAssignDeep = require(`object-assign-deep`)

export class Client {
  options: Options
  private service!: Service

  /**
   * Initiate client instance
   * @param options Optional. Set options for HTTP requests
   */
  constructor(options?: Options) {
    const defaultOptions = {
      baseURL: API.baseUrl,
      version: API.version,
      timeout: API.timeout,
      responseType: 'json',
      signOut: options?.signOut
    }
    this.options = objectAssignDeep({}, defaultOptions, options)
  }

  /**
   * Configure client instance
   * @param options Optional. Set options for HTTP requests
   */
  configure = (options?: Options) => {
    this.options = objectAssignDeep(this.options, options)
    this.service = new Service(this.options)
  }

  getAllRooms = (
    paginationOption: PaginationOption = { page: 1, limit: 10}
  ): Promise<Pagination<dataSchemas.Room>> =>
  this.service.getRooms({
    ...paginationOption
  })

  getRoomById = (
    id: string
  ): Promise<dataSchemas.Room> =>
  this.service.getRoomById(id)


  createRoom = (
    body: dataSchemas.CreateRequest
  ): Promise<string> => this.service.createRoom(body)

  updateRoom = (
    id: string,
    body: dataSchemas.CreateRequest
  ): Promise<string> => this.service.updateRoom(id, body)

  deleteRoom = (
    id: string
  ): Promise<string> => this.service.deleteRoom(id)
}

export * as types from './utils/DataSchemas'
