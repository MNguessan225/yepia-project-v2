import { Image, Location, PaginationOption } from "../../GlobalDataSchemas"


export interface CreateRequest {
  name: string
  location: {
    full_address: string
    city: string
  }
  phone_numbers: string[]
  image: Blob
  new_image?: Blob
}

export interface Room {
  _id: string
  name: string
  location: Location
  image: Image
  phone_numbers: string[]
  created_at: Date
  updated_at: Date
  created_by: string
  updated_by: string
}
