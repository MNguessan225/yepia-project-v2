import request from '../../../api'
import { Options } from '../../../api/DataSchemas'
import { PaginationOption } from '../../GlobalDataSchemas'
import { CreateRequest } from '../utils/DataSchemas'

function getPaginationQuery(paginationOption: PaginationOption) {
    let query = `?page=${paginationOption.page}&limit=${paginationOption.limit}`
    
    return query
  }

export default class Service {
    options: Options

    constructor(options: Options) {
        this.options = options
    }
    async createBanner(data: CreateRequest) {
      const requestOptions: Options = {
        ...this.options,
        data: data
      }
    
      return request('POST', `/banner`, requestOptions)
    }

    async getBanners(paginationOption: PaginationOption) {
      const query = getPaginationQuery(paginationOption)
      return request('GET', `/banner${query}`, this.options)
    }

    async getBannerById(id: string) {
      return request('GET', `/banner/${id}`, this.options)
    }

    async deleteBanner(id: string) {
    
        return request('DELETE', `/banner/${id}`, this.options)
    }

    async updateBanner(id: string , data: CreateRequest) {
      const requestOptions: Options = {
        ...this.options,
        data: data
      }
    
      return request('PUT', `/banner/update/${id}`, requestOptions)
    }
}
