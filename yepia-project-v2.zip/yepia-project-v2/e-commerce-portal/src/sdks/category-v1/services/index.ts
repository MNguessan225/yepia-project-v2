import request from '../../../api'
import { Options } from '../../../api/DataSchemas'
import { PaginationOption } from '../../GlobalDataSchemas'
import { CreateRequest } from '../utils/DataSchemas'

function getPaginationQuery(paginationOption: PaginationOption) {
    let query = `?page=${paginationOption.page}&limit=${paginationOption.limit}`
    
    return query
  }

export default class Service {
    options: Options

    constructor(options: Options) {
        this.options = options
    }
    async createCategory(data: CreateRequest) {
      const requestOptions: Options = {
        ...this.options,
        data: data
      }
    
      return request('POST', `/category`, requestOptions)
    }

    async getCategories(paginationOption: PaginationOption) {
      const query = getPaginationQuery(paginationOption)
      return request('GET', `/category${query}`, this.options)
    }

    async getCategoryById(id: string) {
      return request('GET', `/category/${id}`, this.options)
    }

    async deleteCategory(id: string) {
    
        return request('DELETE', `/category/${id}`, this.options)
    }

    async updateCategory(id: string , data: CreateRequest) {
      const requestOptions: Options = {
        ...this.options,
        data: data
      }
    
      return request('PUT', `/category/update/${id}`, requestOptions)
    }
}
