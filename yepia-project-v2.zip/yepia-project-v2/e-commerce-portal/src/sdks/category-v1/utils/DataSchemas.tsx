export interface CreateRequest {
  name: string
  category_level_two: {
    name: string
  }[]
  category_level_three: {
    name: string
  }[]
}

export interface Category {
  _id: string
  name: string
  slug: string
  category_level_two: {
    name: string
    slug: string
  }[]
  category_level_three: {
    name: string
    slug: string
  }[]
  created_at: Date
  updated_at: Date
  created_by: string
  updated_by: string
}
