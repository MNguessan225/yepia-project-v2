export interface Image {
  image: Blob
  folder: string
}
