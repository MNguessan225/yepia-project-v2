import { UserProfile } from "@/sdks/user-v1/utils/DataSchemas"
import { Image, Location, PaginationOption } from "../../GlobalDataSchemas"


export interface CreateRequest {
  title: string
  description: string
  specifications: string
  category_level_one: {
    name: string
    slug: string
  }
  category_level_two: {
    name: string
    slug: string
  }
  category_level_three: {
    name: string
    slug: string
  }
  brand: string
  model: string
  price: number
  promotion: {
    active: boolean
    cost: number
    start_dt: Date
    end_dt: Date
  }
  images: Image[]
  new_images?: Blob[]
  active: boolean
  status: string
  stock: number
}

export interface Product {
  _id: string
  title: string
  slug: string
  description: string
  specifications: string
  category_level_one: {
    name: string
    slug: string
  }
  category_level_two: {
    name: string
    slug: string
  }
  category_level_three: {
    name: string
    slug: string
  }
  brand: string
  model: string
  price: number
  promotion: {
    active: string
    cost: number
    start_dt: Date
    end_dt: Date
  }
  images: Image[]
  active: boolean
  status: string
  stock: number
  reviews: {
    user: UserProfile
    rating: number
    comment: {
      type: String,
    },
    product_id: string
    created_at: Date
  }[]
  ratings: number
  sold_out: number
  viewed_nb: number
  created_at: Date
  updated_at: Date
  created_by: string
  updated_by: string
}

export interface ReviewRequest {
  user: UserProfile
  rating: number
  comment: string
  orderId: string
}

export interface DescriptionImage {
  image: Blob
}