import { Product } from "../../../sdks/product-v1/utils/DataSchemas"
import { Image, Location, PaginationOption } from "../../GlobalDataSchemas"

export interface UserProfile {
    _id: string
    first_name: string
    last_name: string
    full_name: string
    email_address: string
    location: Location | null
    phone_numbers: Array<string>
    role: string
    gender: string
    action: string
    avatar: Image | null
    is_activated: boolean
    created_at: Date
    updated_at: Date
    created_by: string
    updated_by: string
    wish_list_ids: Array<string>
    viewed_list_ids: Array<string>
    viewed_products: Array<Product>
    wish_products: Array<Product>
}


export interface CreateRequest {
    first_name: string
    last_name: string
    email_address: string
    password: string
    location: {
        full_address: string
        city: string
    }
    phone_numbers: Array<string>
    role: string
    gender: string
    action: string
}

export interface UpdateRequest {
    first_name: string
    last_name: string
    location: {
        full_address: string
        city: string
    }
    phone_numbers: Array<string>
    role: string
    gender: string
    action: string
    is_activated: boolean
}

export interface UpdatePicture {
    avatar: Blob
}

export interface UpdateMyProfileRequest {
    first_name: string
    last_name: string
    location: {
        full_address: string
        city: string
    }
    phone_numbers: Array<string>
    gender: string
    email_address: string
}

export interface ChangePasswordRequest {
    old_password: string
    new_password: string
    confirm_password: string
  }