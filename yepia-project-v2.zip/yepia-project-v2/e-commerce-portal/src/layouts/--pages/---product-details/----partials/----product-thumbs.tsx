import React from 'react'
import ProductImages from './----product-images'

function ProductThumbs() {
  return (
    <div className='--product-thumbs' >
        <ProductImages/>
    </div>
  )
}

export default ProductThumbs