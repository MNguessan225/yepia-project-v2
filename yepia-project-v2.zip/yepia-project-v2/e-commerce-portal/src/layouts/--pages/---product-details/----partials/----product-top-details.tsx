import { moneyFormating } from '../../../../utils/utilities/constants';
import { useCountdown } from '../../../../layouts/--components/--countdown-time';
import React, { useContext, useEffect, useState } from 'react'
import { AuthContext } from '../../../../context/auth';
import toast from 'react-hot-toast';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../../../../utils/redux/features/cartSlice';
import useProduct from '../../../../utils/utilities/hooks/useProduct';

function ProductTopDetails({currentData}: any) {
    const [days, hours, minutes, seconds] = useCountdown(currentData?.promotion?.end_dt ?? null);
    const { sessionInfo, setUserInfo } = useContext(AuthContext)
    const [count, setCount] = useState(1);
    let { client } = useProduct()
    const [click, setClick] = useState(false);
    const dispatch = useDispatch();
    const { cart } = useSelector((state: any) => state.cart);
    const addToCartHandler = (id: string) => {
        const isItemExists = cart && cart.find((i: any) => i._id === id);
        if (isItemExists) {
          toast.error("Produit déjà ajouté au panier !");
        } else {
            const cartData = { ...currentData, qty: count };
            dispatch(addToCart(cartData));
            toast.success("Produit ajouté au panier avec succès!");
        }
    };

    const incrementCount = () => {
        setCount(count + 1);
      };
    
      const decrementCount = () => {
        if (count > 1) {
          setCount(count - 1);
        }
      };

    const likeProduct = async () => {
        if(sessionInfo?.userInfo) {
            try {
                await client.addToWish(currentData?._id)
                setClick(!click);
                toast.success(!click ? "Produit ajouté au favoris!": 'Produit retiré des favoris');
            } catch (error) {
                toast.error("Une erreur s'est produite, veuillez réessayer !");
            }

           
        }else {
            toast('Veuillez vous connecter !', {
                duration: 4000,
                position: 'top-center',
              
                // Styling
                style: {},
                className: '',
              
                // Custom Icon
                icon: '🚨',
              
                // Change colors of success/error/loading icon
                iconTheme: {
                  primary: '#000',
                  secondary: '#fff',
                },
              
                // Aria
                ariaProps: {
                  role: 'status',
                  'aria-live': 'polite',
                },
              });
        }
    }

    useEffect(() => {
        if(currentData && sessionInfo?.userInfo) {
            if (sessionInfo?.userInfo?.wish_list_ids?.find((i: string) => i === currentData?._id)) {
                setClick(true);
              } else {
                setClick(false);
              }
        }
        setCount(1)
    }, [currentData])
    return (
    <div className='--product-top-details' >
        <div className="content_product_detail">
            <h1 className="product_title entry-title">{currentData?.title}</h1>
            <div className="reviews-content">
                <div className="flex items-center">
                    <div className="star" >
                        {Array((Number(currentData?.ratings ?? 0))).fill(undefined).map((v, i) => i + 1).map((data: any, key: number) => {
                            return <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="#FD0505FF" fill="none">
                                <path d="M13.7276 3.44418L15.4874 6.99288C15.7274 7.48687 16.3673 7.9607 16.9073 8.05143L20.0969 8.58575C22.1367 8.92853 22.6167 10.4206 21.1468 11.8925L18.6671 14.3927C18.2471 14.8161 18.0172 15.6327 18.1471 16.2175L18.8571 19.3125C19.417 21.7623 18.1271 22.71 15.9774 21.4296L12.9877 19.6452C12.4478 19.3226 11.5579 19.3226 11.0079 19.6452L8.01827 21.4296C5.8785 22.71 4.57865 21.7522 5.13859 19.3125L5.84851 16.2175C5.97849 15.6327 5.74852 14.8161 5.32856 14.3927L2.84884 11.8925C1.389 10.4206 1.85895 8.92853 3.89872 8.58575L7.08837 8.05143C7.61831 7.9607 8.25824 7.48687 8.49821 6.99288L10.258 3.44418C11.2179 1.51861 12.7777 1.51861 13.7276 3.44418Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                        })}
                        {Array((5 - Number(currentData?.ratings ?? 0))).fill(undefined).map((v, i) => i + 1).map((data: any, key: number) => {
                            return <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="#444444" fill="none">
                            <path d="M13.7276 3.44418L15.4874 6.99288C15.7274 7.48687 16.3673 7.9607 16.9073 8.05143L20.0969 8.58575C22.1367 8.92853 22.6167 10.4206 21.1468 11.8925L18.6671 14.3927C18.2471 14.8161 18.0172 15.6327 18.1471 16.2175L18.8571 19.3125C19.417 21.7623 18.1271 22.71 15.9774 21.4296L12.9877 19.6452C12.4478 19.3226 11.5579 19.3226 11.0079 19.6452L8.01827 21.4296C5.8785 22.71 4.57865 21.7522 5.13859 19.3125L5.84851 16.2175C5.97849 15.6327 5.74852 14.8161 5.32856 14.3927L2.84884 11.8925C1.389 10.4206 1.85895 8.92853 3.89872 8.58575L7.08837 8.05143C7.61831 7.9607 8.25824 7.48687 8.49821 6.99288L10.258 3.44418C11.2179 1.51861 12.7777 1.51861 13.7276 3.44418Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                        })}
                    </div>
                    <a href="#reviews" className="--review-link" rel="nofollow"><span className="count">{currentData?.reviews?.length}</span> Avis </a>
                </div>
                <div className={`product-stock ${currentData?.status === 'in-stock' ? 'in-stock': 'out-stock'}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" color="#444444" fill="none">
                        <path d="M21.8966 6.63081C22.2168 7.52828 21.7678 8.14274 20.8986 8.748C20.1973 9.23636 19.3039 9.76542 18.3572 10.6699C17.4291 11.5566 16.5234 12.6246 15.7184 13.6758C14.743 14.9496 13.8206 16.2801 13.0087 17.6655C12.7026 18.1902 12.1521 18.5078 11.5619 18.4999C10.9716 18.4919 10.4293 18.1597 10.1364 17.6267C9.38765 16.264 8.80986 15.7259 8.5443 15.5326C7.8075 14.9963 7 14.9035 7 13.7335C7 12.7762 7.74623 12.0002 8.66675 12.0002C9.32548 12.0266 9.92854 12.3088 10.4559 12.6927C10.7981 12.9418 11.1605 13.2711 11.5375 13.7047C11.9799 13.051 12.5131 12.2968 13.1107 11.5163C13.9787 10.3829 15.0032 9.16689 16.1019 8.11719C17.1819 7.08531 18.4306 6.11941 19.7542 5.60872C20.6172 5.27573 21.5764 5.73333 21.8966 6.63081Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M4.43961 12.0755C4.28117 12.0236 4.13796 11.9909 4.01252 11.9713C3.94995 11.9615 3.89226 11.955 3.83976 11.951L3.69887 11.9454C2.76061 11.9454 2 12.728 2 13.6933C2 14.5669 2.62294 15.2908 3.43675 15.4205C3.4652 15.4355 3.51137 15.4624 3.57407 15.5076C3.84474 15.7025 4.43367 16.2452 5.19686 17.6193C5.49542 18.1569 6.04811 18.4918 6.64983 18.4999C7.06202 18.5054 7.45518 18.3567 7.76226 18.0924M15 5.5C13.6509 6.015 12.3781 6.98904 11.2773 8.02963C10.8929 8.39299 10.5174 8.77611 10.1542 9.16884" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    <span>{currentData?.status === 'in-stock' ? 'En stock': 'En rupture de stock'}</span>
                </div>
            </div>
            {currentData?.promotion?.active && <div className="--product-countdown" >
                <span className="countdown-row countdown-show4">
                    <span className="countdown-section days">
                    <span className="countdown-amount">{days}</span>
                    <span className="countdown-period">{days > 1 ? 'Jours': 'Jour'}</span>
                    </span>
                    <span className="countdown-section hours">
                        <span className="countdown-amount">{hours}</span>
                        <span className="countdown-period">{hours > 1 ? 'Heures': 'Heure'}</span>
                    </span>
                    <span className="countdown-section mins">
                    <span className="countdown-amount">{minutes}</span>
                    <span className="countdown-period">{minutes > 1 ? 'mins': 'min'}</span>
                    </span>
                    <span className="countdown-section secs">
                    <span className="countdown-amount">{seconds}</span>
                    <span className="countdown-period">{seconds > 1 ? 'secs': 'sec'}</span>
                    </span>
                </span>
            </div>}
            <div>
                <p className="price">
                {currentData?.promotion?.active && <del aria-hidden="true">
                        <span className="woocommerce-Price-amount amount"  >{moneyFormating(currentData?.price ?? 0)}</span>
                    </del>}
                   <ins><span className="woocommerce-Price-amount amount" >{moneyFormating(currentData?.promotion?.active ? (currentData?.promotion?.cost ?? 0) : (currentData?.price ?? 0))}</span></ins>
                </p>
            </div>
            {currentData?.specifications && <div className="product-description" itemProp="description">
                <h2 className="quick-overview">Spécifications</h2>
                <p dangerouslySetInnerHTML={{__html: currentData.specifications}} />
            </div>}
            <div className="product-summary-bottom clearfix">
                <form className="cart" >
                    <div className="quantity buttons_added">
                        <input type="button" defaultValue="-" className="minus" onClick={decrementCount}/>
                        <input type="text" id="quantity_66767edf650e2" className="input-text qty text" name="quantity" defaultValue={1} value={count} title="Qty" size={4} min={1} step={1} inputMode="numeric" autoComplete="off" />
                        <input type="button" defaultValue="+" className="plus"  onClick={incrementCount}/>
                    </div>
                    <button type="button" 
                    onClick={() => addToCartHandler(currentData?._id)}
                    name="add-to-cart" value={714} className="single_add_to_cart_button button alt wp-element-button">Ajouter au panier</button>
                    <button 
                    onClick={() => likeProduct()}
                    type="button" name="add-to-cart" value={714} className={`single_add_to_favrite_button button alt wp-element-button ${click ? 'active': ''} `}>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" color="#444444" fill="none">
                            <path d="M19.4626 3.99415C16.7809 2.34923 14.4404 3.01211 13.0344 4.06801C12.4578 4.50096 12.1696 4.71743 12 4.71743C11.8304 4.71743 11.5422 4.50096 10.9656 4.06801C9.55962 3.01211 7.21909 2.34923 4.53744 3.99415C1.01807 6.15294 0.221721 13.2749 8.33953 19.2834C9.88572 20.4278 10.6588 21 12 21C13.3412 21 14.1143 20.4278 15.6605 19.2834C23.7783 13.2749 22.9819 6.15294 19.4626 3.99415Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        </svg>
                    </button>
                </form>
            </div>
        </div>
    </div>
  )
}

export default ProductTopDetails