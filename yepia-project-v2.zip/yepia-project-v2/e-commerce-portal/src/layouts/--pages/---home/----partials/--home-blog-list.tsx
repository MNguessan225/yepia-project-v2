import BlogCard from '../../../--components/--blog-card'
import React from 'react'

function HomeBlogList() {
  return (
    <div className='--home-blog-list' >
        <div className="wrapper">
            <div className="--home-blog-list-title"><h2>Nos <span>récentes</span> actualités</h2></div>

            <div className="w-full grid grid-cols-2">
                <BlogCard/>
                <BlogCard/>
                <BlogCard/>
                <BlogCard/>
                <BlogCard/>
                <BlogCard/>
            </div>
        </div>

        
    </div>
  )
}

export default HomeBlogList