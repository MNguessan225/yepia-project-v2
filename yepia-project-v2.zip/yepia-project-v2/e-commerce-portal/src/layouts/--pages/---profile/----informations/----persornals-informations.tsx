import React from 'react'

function PersonnalsInformations() {
  return (
    <form className="EditAccountForm edit-account"  method="post">
  <p className="form-row form-row--first form-row form-row-first">
    <label htmlFor="account_first_name">First name&nbsp;<span className="required">*</span></label>
    <input type="text" className="Input Input--text input-text" name="account_first_name" id="account_first_name" autoComplete="given-name" defaultValue="Marx" />
  </p>
  <p className="form-row form-row--last form-row form-row-last">
    <label htmlFor="account_last_name">Last name&nbsp;<span className="required">*</span></label>
    <input type="text" className="Input Input--text input-text" name="account_last_name" id="account_last_name" autoComplete="family-name" defaultValue="N'Guessan" />
  </p>
  
  <div className="clear" />
  <p className='p-[3px]'>
    <button type="submit" className="Button button wp-element-button" name="save_account_details" value="Save changes">Save changes</button>
  </p>
</form>

  )
}

export default PersonnalsInformations