import React from 'react'

function BlogCard() {
  return (
    <div className="blog-item pull-left">
        <div className="latest-blog-inner clearfix">
            <div className="widget-thumb pull-left">
            <a href="./product/id" title="mattis imperdiet nunc"><img width={292} height={203} src="https://demo1.wpthemego.com/themes/sw_furnicom/wp-content/uploads/2016/02/5-292x203.png" className="attachment-furnicom_lastest_blog size-furnicom_lastest_blog wp-post-image" alt=""/></a>
            <div className="entry-date">
                <div className="day-post">25</div>
                <div className="mon-post">May</div>
            </div>
            </div>
            <div className="widget-content-wrap">
            <div className="widget-content">
                <div className="item-title">
                <h4><a href="./product/id" title="mattis imperdiet nunc">mattis imperdiet nunc</a></h4>
                </div>
                <div className="item-content">
                <p>
                    Aliquam sem sem, ultricies ut facilisis vel, varius eget lorem. Suspendisse sollicitudin nisi luctus lorem</p>
                </div>
                <div className="bl_read_more"><a href="./product/id">Lire plus<i className="fa fa-angle-double-right" /></a></div>
            </div>
            </div>
        </div>
    </div>

  )
}

export default BlogCard