import React from 'react'

function FeatureItem() {
  return (
    <div>FeatureItem</div>
  )
}

export default FeatureItem