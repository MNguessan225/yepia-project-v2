import React from 'react'

function FavoriteProductCard() {
  return (
    <div>FavoriteProductCard</div>
  )
}

export default FavoriteProductCard