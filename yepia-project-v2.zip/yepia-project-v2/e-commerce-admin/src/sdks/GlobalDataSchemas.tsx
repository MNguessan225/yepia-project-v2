export interface PaginationOption {
    page?: number
    limit?: number
    search?: string
    role?: string
    status?: string
    not_status?: string
}

export interface Pagination<T> {
    search: string,
    totalDocs: number,
    limit: number,
    totalPages: number,
    page: number,
    pagingCounter: number,
    hasPrevPage: boolean,
    hasNextPage: boolean,
    prevPage: string | null,
    nextPage: string | null
    results: Array<T>
}


export interface Location {
    full_address: string
    city: string
    country: string
    country_flag: string
    coordinates: string[]
}

export interface Image {
    public_id: string
    url: string
  }