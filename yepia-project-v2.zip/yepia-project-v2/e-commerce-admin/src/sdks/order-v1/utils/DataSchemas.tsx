import { UserProfile } from "@/sdks/user-v1/utils/DataSchemas"
import { Image, Location, PaginationOption } from "../../GlobalDataSchemas"


export interface CreateRequest {
  cart: Array<any>
  shipping_address: any
  shipping_cost: number
  notes: string
  total_price: number
  status?: string
  delivered_at?: Date
  assigned_to?: string
  failed_delivery_note?: string
  not_refunded_note?: string
}

export interface Order {
  _id: string
  cart: Array<any>
  shipping_address: any
  user: any
  shipping_cost: number
  notes: string
  total_price: number
  status: string
  delivered_at: Date
  tracking: Array<any>
  assigned_to: string
  created_at: Date
  updated_at: Date
  updated_by: string
  failed_delivery_note: string
  not_refunded_note: string
}