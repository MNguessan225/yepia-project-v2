import { UserProfile } from "@/sdks/user-v1/utils/DataSchemas"

export interface AuthorizeRequest {
  email_address: string
  password: string
}

export interface AuthorizeResponse {
  user: UserProfile
  acces_token: string
  refresh_token: string
}

export interface ResetPasswordCodeRequest {
  email_address: string
}

export interface PasswordResetCodeRequest {
  change_pass_token: string
  password: string
  confirm_password: string
}


export interface RegisterRequest {
  first_name: string
  last_name: string
  email_address: string
  password: string
  location: {
      full_address: string
      city: string
  }
  phone_numbers: string[]
  role: string
  gender: string
  action: string
  is_activated: boolean
}

export interface ActivateRequest {
  activation_token: string
}