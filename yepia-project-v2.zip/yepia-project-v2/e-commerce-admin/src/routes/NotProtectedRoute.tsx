import React from "react";
import { useSelector } from "react-redux";
import { Navigate, useNavigate } from "react-router-dom";

const NotProtectedRoute = ({ children }: {children: React.ReactNode}) => {
  const navigate = useNavigate()
  // const { loading, isAuthenticated, user } = useSelector((state: any) => state.user);

  const loading = false;
  const isAuthenticated = true;
  const user = {
    role : 'admin'
  }
  if (loading === false) {
    return <>
    {
      !isAuthenticated && children
    }
    </>;
  }
};

export default NotProtectedRoute;
