import React from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const AuthIsSignedIn = ({ children }: {children: React.ReactNode}) => {
  const navigate = useNavigate()
  // const { loading, isAuthenticated, user } = useSelector((state: any) => state.user);
  const loading = false;
  const isAuthenticated = true;
  const user = {
    role : 'admin'
  }
  if (loading === false) {
    return <>
    {
      isAuthenticated && user.role === 'admin' && children
    }
    </>;
  }
};

export default AuthIsSignedIn;
