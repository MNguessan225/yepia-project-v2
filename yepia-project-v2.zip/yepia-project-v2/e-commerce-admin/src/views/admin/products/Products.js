import { useQuery } from "@tanstack/react-query";
import React, { useState } from "react";
import { useNavigate } from "react-router";
import useProduct from '../../../utils/utilities/hooks/useProduct';
import TablePagination from "../../../components/TablePagination";
// components
let timer = null
export default function ProductData() {
  const navigate = useNavigate()
  let { client } = useProduct()

  const [page, setPage] = useState(1);
  const [limit, _] = useState(10);
  const [searchText, setSearchText] =
  useState("");
const [value, setValue] =
  useState("");
  const {
    data: productData,
    isLoading
  } = useQuery({
    queryKey: ["products-data", page, limit, searchText],
    queryFn: async () => {
      let result = await client.getAdminProducts({ page, limit, search: searchText})
      return result;
    },
    keepPreviousData: true
  });
  const handleFilter = (e) => {
    setPage(1)
    setValue(e.target.value)
    if (timer) clearTimeout(timer)
    timer = setTimeout(async () => {
      try {
         setSearchText(e.target.value)
      } catch (error) {
        console.warn(error);
      }
    }, 1000)
  }
 
  return (
    <>
      <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
        <div className="rounded-t mb-0 px-4 py-3 border-0">
          <div className="flex flex-wrap items-center">
            <div className="relative w-full max-w-full flex-grow flex-1">
              <h3 className="font-semibold text-base text-blueGray-700">
                Produits
              </h3>
            </div>

            <div className="relative w-full max-w-full flex-grow flex-1">
            <input
                    type="text"
                    className="border-0 px-3 py-3 placeholder-blueGray-500 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none w-full ease-linear transition-all duration-150"
                    placeholder="Rechercher..."
                    value={value}
                    onChange={handleFilter}
                  />
            </div>
           
            <div className="relative w-full max-w-full flex-grow flex-1 text-right">
              <button
                className="bg-indigo-500 text-white active:bg-indigo-600 text-xs font-bold uppercase px-3 py-1 rounded outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                type="button"
                onClick={() => {
                  navigate('/products/form')
                }}
              >
                Créer
              </button>
            </div>
          </div>
        </div>
        <div className="block w-full overflow-x-auto">
          {/* Projects table */}

          <table className="items-center w-full bg-transparent border-collapse">
            <thead>
              <tr>
                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                  Libellé
                </th>
                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                    Prix
                </th>

                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                    Statut
                </th>

                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                    Stock
                </th>

                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                    Ventes
                </th>
                
                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-right">
                    Actions
                </th>
              </tr>
            </thead>
            <tbody>

              {isLoading &&
                <tr>
                  <td colSpan={6}>
                    <div
                      style={{
                        fontSize: 16,
                        fontWeight: 700,
                        padding: 24,
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      ><span style={{color: '#263238'}}>Chargement des données ... </span>
                        
                      </div>
                  </td>
                </tr>
              }

              
              {
                productData?.results?.length ?<>
                {productData?.results?.map((u, index) => {
                return <tr>
                <th className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4 text-left">
                  <div className="w-full flex items-center gap-3"  >
                    <img src={u.images[0].url} className="w-10 h-10 rounded-full"  /> 
                    <p className="truncate text-ellipsis max-w-[300px] " >{u.title}</p>
                  </div>
                </th>
                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                {u?.promotion?.active ? u.promotion.cost : u.price}
                </td>

                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                  {u.active ?  <i className="fas fa-arrow-up text-emerald-500 mr-4"></i> : <i className="fas fa-arrow-down text-orange-500 mr-4"></i>}
                  {u.active ? 'Actif' : 'Inactif'}
                </td>

                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                {u.stock}
                </td>

                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                {u.sold_out}
                </td>

                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                    <div className="relative w-full max-w-full flex-grow flex-1 text-right">
                        <button
                          onClick={() => {
                            navigate(`/products/form/${u._id}`)
                          }}
                            className="bg-indigo-500 text-white active:bg-indigo-600 text-xs font-bold uppercase px-3 py-1 rounded outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                            type="button"
                        >
                            <i className="fas fa-solid fa-highlighter"></i>
                        </button>
                    </div>
                </td>

                
              </tr>
              })}
                </> : <tr>
                <td colSpan={6}>
                  
                    <div className="font-bold" style={{padding: "15px 0px", display: 'flex', justifyContent: 'center', alignItems: "center", color: '#263238'}}>Aucune données</div>
                  </td></tr>
              }
              
            </tbody>
          </table>

          {productData?.results?.length ?  productData?.results && (
                <TablePagination
                  data={productData}
                  limit={limit}
                  currentPage={page}
                  setCurrentPage={setPage}
                />
              ): <></>}


        </div>
      </div>
    </>
  );
}