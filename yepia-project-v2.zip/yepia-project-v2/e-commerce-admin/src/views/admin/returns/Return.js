import { useQuery } from "@tanstack/react-query";
import React, { useContext, useState } from "react";
import { useNavigate } from "react-router";
import useOrder from '../../../utils/utilities/hooks/useOrder';
import TablePagination from "../../../components/TablePagination";
import moment from "moment";
import { AuthContext } from "../../../context/auth";
let timer = null
// components
export default function ReturnData() {
  const { sessionInfo, setUserInfo } = useContext(AuthContext)
  const navigate = useNavigate()
  let { client } = useOrder()

  const [page, setPage] = useState(1);
  const [limit, _] = useState(10);

  const [searchText, setSearchText] =
  useState("");
const [value, setValue] =
  useState("");
  const {
    data: orderData,
    isLoading
  } = useQuery({
    queryKey: ["returns-data", page, limit , searchText],
    queryFn: async () => {

      let result = await client.getReturns({ page, limit, search: searchText})
        return result;
      
    },
    keepPreviousData: true
  });


  const getStatusLabel = (status) => {
    
    switch (status) {

      case 'pending':
        return 'En attente';
        break;

      case 'processing':
        return 'En traitement';
        break;

      case 'shipping':
        return 'En cours de livraison';
        break;

      case 'refund-request':
        return 'Processus de retour';
        break;

      case 'refunded':
        return 'Remboursé';
        break;

      case 'cancelled':
        return 'Annulé';
        break;
        
      case 'not-delivered':
        return 'Echec de livraison';
        break;
      case 'delivered':
        return 'Livré';
        break;
    
      default:
        break;
    }
  }

  const handleFilter = (e) => {
    setPage(1)
    setValue(e.target.value)
    if (timer) clearTimeout(timer)
    timer = setTimeout(async () => {
      try {
         setSearchText(e.target.value)
      } catch (error) {
        console.warn(error);
      }
    }, 1000)
  }
 
  return (
    <>
      <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
        <div className="rounded-t mb-0 px-4 py-3 border-0">
          <div className="flex flex-wrap items-center">
            <div className="relative w-full max-w-full flex-grow flex-1">
              <h3 className="font-semibold text-base text-blueGray-700">
                Retours de produits
              </h3>
            </div>

            <div className="relative w-full max-w-full flex-grow flex-1">
            <input
                    type="text"
                    className="border-0 px-3 py-3 placeholder-blueGray-500 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none w-full ease-linear transition-all duration-150"
                    placeholder="Rechercher..."
                    value={value}
                    onChange={handleFilter}
                  />
            </div>
           
          </div>
        </div>
        <div className="block w-full overflow-x-auto">
          {/* Projects table */}

          <table className="items-center w-full bg-transparent border-collapse">
            <thead>
              <tr>
                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                  N° Commande
                </th>

                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                    Utilisateur
                </th>
                
                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                  Date
                </th>

                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                    Status
                </th>
                
                <th className="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-right">
                    Actions
                </th>
              </tr>
            </thead>
            <tbody>

              {isLoading &&
                <tr>
                  <td colSpan={6}>
                    <div
                      style={{
                        fontSize: 16,
                        fontWeight: 700,
                        padding: 24,
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                      ><span style={{color: '#263238'}}>Chargement des données ... </span>
                        
                      </div>
                  </td>
                </tr>
              }

              
              {
                orderData?.results?.length ?<>
                {orderData?.results?.map((u, index) => {
                return <tr>
                <th className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4 text-left">
                  <div className="w-full flex items-center gap-3"  >
                    <p className="truncate text-ellipsis max-w-[300px] " >#{u._id}</p>
                  </div>
                </th>
                
                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                {u.user?.full_name} / {u?.user?.phone_numbers && u?.user?.phone_numbers[0]} {u?.shipping_address?.phone_number ? `-${u?.shipping_address?.phone_number}` : ''}
                </td>

                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                  {moment(u?.created_at).format('DD MMMM YYYY hh:m:s')}
                </td>

                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                {u.status === 'delivered' ?  <i className="fas fa-arrow-up text-emerald-500 mr-4"></i> : u.status === 'cancelled' ? <i className="fas fa-arrow-down text-orange-500 mr-4"></i> : <i className="fas fa-arrow-right text-gray-500 mr-4"></i>} {getStatusLabel(u?.status)}
                </td>

                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                    <div className="relative w-full max-w-full flex-grow flex-1 text-right">
                        <button
                          onClick={() => {
                            navigate(`/returned-products/view/${u._id}`)
                          }}
                            className="bg-indigo-500 text-white active:bg-indigo-600 text-xs font-bold uppercase px-3 py-1 rounded outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                            type="button"
                        >
                            <i className="fas fa-solid fa-highlighter"></i>
                        </button>
                    </div>
                </td>

                
              </tr>
              })}
                </> : <tr>
                <td colSpan={6}>
                  
                    <div className="font-bold" style={{padding: "15px 0px", display: 'flex', justifyContent: 'center', alignItems: "center", color: '#263238'}}>Aucune données</div>
                  </td></tr>
              }
              
            </tbody>
          </table>

          {orderData?.results?.length ?  orderData?.results && (
                <TablePagination
                  data={orderData}
                  limit={limit}
                  currentPage={page}
                  setCurrentPage={setPage}
                />
              ): <></>}


        </div>
      </div>
    </>
  );
}